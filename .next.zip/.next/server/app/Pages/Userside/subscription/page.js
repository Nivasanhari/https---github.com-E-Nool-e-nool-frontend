(() => {
var exports = {};
exports.id = 937;
exports.ids = [937];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 2553:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'Pages',
        {
        children: [
        'Userside',
        {
        children: [
        'subscription',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8837)), "C:\\Project\\e-nool-frontend\\app\\Pages\\Userside\\subscription\\page.jsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9376)), "C:\\Project\\e-nool-frontend\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Project\\e-nool-frontend\\app\\Pages\\Userside\\subscription\\page.jsx"];

    

    const originalPathname = "/Pages/Userside/subscription/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/Pages/Userside/subscription/page","pathname":"/Pages/Userside/subscription","bundlePath":"app/Pages/Userside/subscription/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 8533:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 565));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5189));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2417));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9942));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8702));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4899));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4745));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5906));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4874));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1488));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 177))

/***/ }),

/***/ 8837:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ subscription_page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(4178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(2947);
// EXTERNAL MODULE: ./public/assets/aboutbg.png
var aboutbg = __webpack_require__(5632);
// EXTERNAL MODULE: ./public/assets/Leaf.png
var Leaf = __webpack_require__(7806);
// EXTERNAL MODULE: ./public/assets/Lefe1.png
var Lefe1 = __webpack_require__(2758);
;// CONCATENATED MODULE: ./public/assets/Pricing.png
/* harmony default export */ const Pricing = ({"src":"/_next/static/media/Pricing.4c08a810.png","height":200,"width":704,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAKUlEQVR4nGNk8EviZGBg+AvE/6GYEUoBif9Ajl8SK5D3HwgZwRCVzQQAoNILbxL2boMAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./public/assets/pricingimg.png
/* harmony default export */ const pricingimg = ({"src":"/_next/static/media/pricingimg.14442ba0.png","height":242,"width":92,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAAICAYAAAA870V8AAAAc0lEQVR4nAFoAJf/AVU6PH8RBARmz+f3MAEAADpcaEUUhJi7siAB+aFbu9ro9kLz+fRvAfagV//u9fwAqsD3xgGjZErZMCfoJunnC98BoF1IexIoJIT+ChazAW6KsDL3BwrN9fr4yQFwmcBQAPv6Wuff0Qr8DTO+jzm91QAAAABJRU5ErkJggg==","blurWidth":3,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/rs.png
/* harmony default export */ const rs = ({"src":"/_next/static/media/rs.b596ddc5.png","height":37,"width":17,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAUElEQVR42mMAAeaQFEamkBQmBjAIS2NkQAEhKQFAPAeINwOxFwNjSEoQEO8C4v9A7A1SEc0YnPwSyPFkgIPg5AKgwFZ0s/KBKtXBbCADbhMA2eQVP1GwLEMAAAAASUVORK5CYII=","blurWidth":4,"blurHeight":8});
// EXTERNAL MODULE: ./public/assets/img1.png
var img1 = __webpack_require__(1152);
// EXTERNAL MODULE: ./public/assets/Ellipse.png
var Ellipse = __webpack_require__(6385);
// EXTERNAL MODULE: ./public/assets/Lefe2.png
var Lefe2 = __webpack_require__(9995);
// EXTERNAL MODULE: ./public/assets/Leaf2.png
var Leaf2 = __webpack_require__(5473);
;// CONCATENATED MODULE: ./public/assets/tick.png
/* harmony default export */ const tick = ({"src":"/_next/static/media/tick.df82dc7d.png","height":18,"width":18,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAs0lEQVR42i1OOwoCMRAdEMHCQjttXT+9ytqK4A08gdfYxMoLWIoENSKLhSDsxDMke6p9w87AY2bey3sZkjIprIoYXkViZ2LISMvU3CeQuUlc4tFCSBv/Hekw7MFdCI63idVUya72HcSPbRPCDcsQOKu4xfw91dyDeSwJrhX4COEHOJt4oLd5cfgiVhPsknbAPSM1zIEHSN5A8CZyJoKKM/AlkMsu3yxBPhF5x3zFLH1NRNQAbaVv+hZAAYUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./app/Pages/Userside/subscription/page.jsx














const page = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: " relative h-[450px]",
                src: aboutbg/* default */.Z
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " flex justify-between top-48 absolute ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: " absolute ml-0 w-[65px]",
                        src: Leaf/* default */.Z,
                        alt: ""
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " ml-[350px] h-[200]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " w-[450px] mt-40",
                                src: Pricing,
                                alt: "pricing-img"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " ml-5 text-[#015464] text-5xl font-extrabold mt-[-20px]",
                                children: "Subscription"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " ml-40",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " w-28 ml-32  mt-5",
                                src: pricingimg,
                                alt: "pricing-img"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " absolute ml-[400px] w-28 mt-[-400px]",
                                src: Lefe1/* default */.Z,
                                alt: ""
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " mt-28 ml-28 bg-white ",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " ml-28",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " text-[#015464] font-extrabold text-4xl",
                                children: "Silver"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: " mt-2 text-[14px]  text-[#01adad] font-bold",
                                children: "Low-cost affordable reading to get you started."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex mt-[-50px]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-[350px] h-96 ml-24 lg:mt-16 max-w-sm mb-52",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "bg-white shadow-2xl rounded-b-3xl pb-6 pr-8 justify-center flex",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: " text-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: " mt-1 text-[#015464] ml-7 text-center text-2xl font-extrabold pt-6",
                                                children: "SILVER PLAN 01"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-center ml-5 mt-2 text-[14px]  text-[#015464] font-bold",
                                                children: "Low-cost affordable reading to get you started."
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: " flex ml-20 mt-10",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: rs,
                                                        className: " ml-14 ",
                                                        alt: "rs"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "text-center text-7xl  text-[#14adad] font-bold",
                                                        children: "5"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: " text-center ml-6 text-[#015464] font-semibold",
                                                children: "PRE MONTH"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: " text-sm m-auto ml-3 mt-3  bg-[#7CC9B5] text-[#015464] ",
                                                children: "Renews june 2023 for ₹5.00/mo (₹ 60.00total)"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                className: " bg-[#015464] text-white mt-10 p-2 px-8 rounded-xl ml-[70px]",
                                                children: "SUBSCRIBR NOW"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: " flex gap-5 ml-16 mt-10",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: tick,
                                                        alt: "tick"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: " text-[#015464] font-semibold",
                                                        children: "lorem ipsum"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: " flex gap-5 ml-16 mt-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: tick,
                                                        alt: "tick"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: " text-[#015464] font-semibold",
                                                        children: "lorem ipsum"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: " flex gap-5 ml-16 mt-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: tick,
                                                        alt: "tick"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: " text-[#015464] font-semibold",
                                                        children: "lorem ipsum"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-[350px] h-96 mt-[50px] ml-10 lg:mt-16 max-w-sm mb-52",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "bg-white shadow-2xl rounded-b-3xl pb-6 pr-8 justify-center flex",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: " text-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: " mt-1 text-[#015464] ml-7 text-center text-2xl font-extrabold pt-6",
                                                children: "SILVER PLAN 02"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-center ml-5 mt-2 text-[14px]  text-[#015464] font-bold",
                                                children: "Low-cost affordable reading to get you started."
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: " flex ml-20 mt-10",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: rs,
                                                        className: " ml-14 ",
                                                        alt: "rs"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "text-center text-7xl  text-[#14adad] font-bold",
                                                        children: "15"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: " text-center ml-6 text-[#015464] font-semibold",
                                                children: "PRE MONTH"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: " text-sm m-auto ml-3 mt-3  bg-[#7CC9B5] text-[#015464] ",
                                                children: "Renews june 2023 for ₹5.00/mo (₹ 60.00total)"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                className: " bg-[#015464] text-white mt-10 p-2 px-8 rounded-xl ml-[70px]",
                                                children: "SUBSCRIBR NOW"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: " flex gap-5 ml-16 mt-10",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: tick,
                                                        alt: "tick"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: " text-[#015464] font-semibold",
                                                        children: "lorem ipsum"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: " flex gap-5 ml-16 mt-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: tick,
                                                        alt: "tick"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: " text-[#015464] font-semibold",
                                                        children: "lorem ipsum"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: " flex gap-5 ml-16 mt-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: tick,
                                                        alt: "tick"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: " text-[#015464] font-semibold",
                                                        children: "lorem ipsum"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-[350px] h-96 mt-[50px] ml-10 lg:mt-16 max-w-sm mb-52",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "bg-white shadow-2xl rounded-b-3xl pb-6 pr-8 justify-center flex",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: " text-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: " mt-1 text-[#015464] ml-7 text-center text-2xl font-extrabold pt-6",
                                                children: "SILVER PLAN 03"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-center ml-5 mt-2 text-[14px]  text-[#015464] font-bold",
                                                children: "Low-cost affordable reading to get you started."
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: " flex ml-20 mt-10",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: rs,
                                                        className: " ml-14 ",
                                                        alt: "rs"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "text-center text-7xl  text-[#14adad] font-bold",
                                                        children: "25"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: " text-center ml-6 text-[#015464] font-semibold",
                                                children: "PRE MONTH"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: " text-sm m-auto ml-3 mt-3  bg-[#7CC9B5] text-[#015464] ",
                                                children: "Renews june 2023 for ₹5.00/mo (₹ 60.00total)"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                className: " bg-[#015464] text-white mt-10 p-2 px-8 rounded-xl ml-[70px]",
                                                children: "SUBSCRIBR NOW"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: " flex gap-5 ml-16 mt-10",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: tick,
                                                        alt: "tick"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: " text-[#015464] font-semibold",
                                                        children: "lorem ipsum"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: " flex gap-5 ml-16 mt-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: tick,
                                                        alt: "tick"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: " text-[#015464] font-semibold",
                                                        children: "lorem ipsum"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: " flex gap-5 ml-16 mt-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: tick,
                                                        alt: "tick"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: " text-[#015464] font-semibold",
                                                        children: "lorem ipsum"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " absolute top-[600px] left-[1550px] w-[120px]",
                                src: Leaf2/* default */.Z
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " absolute top-[700px] left-[1300px] w-[120px]",
                                src: Lefe2/* default */.Z,
                                alt: ""
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " absolute top-[800px] left-[1380px] w-[350px]",
                                src: img1/* default */.Z,
                                alt: ""
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " absolute w-24 left-[1550px] mt-[600px]",
                                src: Ellipse/* default */.Z,
                                alt: ""
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const subscription_page = (page);


/***/ }),

/***/ 2758:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Lefe1.7cd3c653.png","height":321,"width":164,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAfElEQVR42mNIOzBRzmdnCwcDEITu7mBkSN4/IS92b09Z8O52AQYQiNrbbZi4r29G5J4uPQYYSNjXZ5eyf6IfAwiUHJnFmnFgskzqgYnWmQcn2zLE7O1hSdrfXwI0UKjs6Gw2BhBIOzDJCSjIywADhYdnyBQdninCwMDAAAD7WCsf8H+m5wAAAABJRU5ErkJggg==","blurWidth":4,"blurHeight":8});

/***/ }),

/***/ 2417:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Lefe1.7cd3c653.png","height":321,"width":164,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAfElEQVR42mNIOzBRzmdnCwcDEITu7mBkSN4/IS92b09Z8O52AQYQiNrbbZi4r29G5J4uPQYYSNjXZ5eyf6IfAwiUHJnFmnFgskzqgYnWmQcn2zLE7O1hSdrfXwI0UKjs6Gw2BhBIOzDJCSjIywADhYdnyBQdninCwMDAAAD7WCsf8H+m5wAAAABJRU5ErkJggg==","blurWidth":4,"blurHeight":8});

/***/ }),

/***/ 4874:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Pricing.4c08a810.png","height":200,"width":704,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAKUlEQVR4nGNk8EviZGBg+AvE/6GYEUoBif9Ajl8SK5D3HwgZwRCVzQQAoNILbxL2boMAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 5906:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/pricingimg.14442ba0.png","height":242,"width":92,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAAICAYAAAA870V8AAAAc0lEQVR4nAFoAJf/AVU6PH8RBARmz+f3MAEAADpcaEUUhJi7siAB+aFbu9ro9kLz+fRvAfagV//u9fwAqsD3xgGjZErZMCfoJunnC98BoF1IexIoJIT+ChazAW6KsDL3BwrN9fr4yQFwmcBQAPv6Wuff0Qr8DTO+jzm91QAAAABJRU5ErkJggg==","blurWidth":3,"blurHeight":8});

/***/ }),

/***/ 1488:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/rs.b596ddc5.png","height":37,"width":17,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAUElEQVR42mMAAeaQFEamkBQmBjAIS2NkQAEhKQFAPAeINwOxFwNjSEoQEO8C4v9A7A1SEc0YnPwSyPFkgIPg5AKgwFZ0s/KBKtXBbCADbhMA2eQVP1GwLEMAAAAASUVORK5CYII=","blurWidth":4,"blurHeight":8});

/***/ }),

/***/ 177:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/tick.df82dc7d.png","height":18,"width":18,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAs0lEQVR42i1OOwoCMRAdEMHCQjttXT+9ytqK4A08gdfYxMoLWIoENSKLhSDsxDMke6p9w87AY2bey3sZkjIprIoYXkViZ2LISMvU3CeQuUlc4tFCSBv/Hekw7MFdCI63idVUya72HcSPbRPCDcsQOKu4xfw91dyDeSwJrhX4COEHOJt4oLd5cfgiVhPsknbAPSM1zIEHSN5A8CZyJoKKM/AlkMsu3yxBPhF5x3zFLH1NRNQAbaVv+hZAAYUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [152,131,210,349,61,215], () => (__webpack_exec__(2553)));
module.exports = __webpack_exports__;

})();