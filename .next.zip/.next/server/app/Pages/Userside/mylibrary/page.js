(() => {
var exports = {};
exports.id = 783;
exports.ids = [783];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 6131:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'Pages',
        {
        children: [
        'Userside',
        {
        children: [
        'mylibrary',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5376)), "C:\\Project\\e-nool-frontend\\app\\Pages\\Userside\\mylibrary\\page.jsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9376)), "C:\\Project\\e-nool-frontend\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Project\\e-nool-frontend\\app\\Pages\\Userside\\mylibrary\\page.jsx"];

    

    const originalPathname = "/Pages/Userside/mylibrary/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/Pages/Userside/mylibrary/page","pathname":"/Pages/Userside/mylibrary","bundlePath":"app/Pages/Userside/mylibrary/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 9280:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7334))

/***/ }),

/***/ 7334:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ mylibrary_page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./app/Components/addBook/page.jsx


const page = ({ isVisivle })=>{
    if (!isVisivle) return null;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: " fixed inset-0 bg-[#015464] bg-opacity-40 flex justify-center items-center",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: " bg-[#015464] h-[550px] rounded-2xl",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: " flex text-white mt-8 ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: " text-xl font-extrabold ml-24",
                            children: "Create booksshelves deatils"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: " text-xl ml-32 mr-10 bg-[#7CC9B5] rounded-full p-1 px-3 text-white bg-opacity-25",
                            children: " \xd7 "
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                    className: " bg-[#7CC9B5] p-[0.5px] mt-5"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: " text-white mt-10 ml-14",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: " text-sm font-light mb-5",
                            children: "My Bookshelf tittle"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            className: " outline-none text-black p-3 pr-28 rounded-lg text-sm",
                            type: "text"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: " text-[12px] mt-1 font-light",
                            children: "Bookshels Name Must Be Between 1-60 characters"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: " mt-8 font-light text-sm",
                            children: "Descreption"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                            className: " mt-6 outline-0 rounded text-[11px]",
                            type: "type",
                            cols: "60",
                            rows: "8"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: " text-white bg-[#7CC9B5] px-28 mt-6 ml-32 p-2 rounded-2xl",
                    children: "Save"
                })
            ]
        })
    });
};
/* harmony default export */ const addBook_page = (page);

// EXTERNAL MODULE: ./public/assets/bg1.png
var bg1 = __webpack_require__(6315);
;// CONCATENATED MODULE: ./public/assets/book.png
/* harmony default export */ const book = ({"src":"/_next/static/media/book.5550b65e.png","height":325,"width":219,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAYAAAAx8TU7AAAApklEQVR42gVATw+BUAD/vWS8JmvWlK3NheFi3WycXYzP7Ghz4OCCXFoaMtVKfxTvGZnPzJS2e5SKhNu3J2kheItD5UeJSuEkIAO9DskPJcF1AlQiC2y3wUgt4D4IIwD4WNcwbYQ4RR+sPXzF1WIJsAJdQwHPGeztGWJfb0JTa9gf7piYHbzsOgSZZbj6Jaq6AcsrIWeRIFyOXpYkHHKF8zguEeW19A/EPEZVrui5jQAAAABJRU5ErkJggg==","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./app/Components/staricon/Staricon.jsx
// components/StarRating.js
/* __next_internal_client_entry_do_not_use__ default auto */ 

const StarRating = ({ initialValue })=>{
    const [rating, setRating] = (0,react_.useState)(initialValue);
    const handleRatingChange = (newRating)=>{
        setRating(newRating);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: " text-xl ml-2 cursor-pointer",
        children: [
            1,
            2,
            3,
            4,
            5
        ].map((index)=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: `star ${rating >= index ? "filled" : ""}`,
                onClick: ()=>handleRatingChange(index),
                children: "★"
            }, index))
    });
};
/* harmony default export */ const Staricon = (StarRating);

// EXTERNAL MODULE: ./public/assets/Lefe1.png
var Lefe1 = __webpack_require__(2417);
// EXTERNAL MODULE: ./public/assets/img1.png
var img1 = __webpack_require__(4899);
;// CONCATENATED MODULE: ./public/assets/Add.png
/* harmony default export */ const Add = ({"src":"/_next/static/media/Add.614a8e2f.png","height":208,"width":175,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAAd0lEQVR42kXNMWpCYQDD8V8eH3QoHTq49B69W4deyyO4CC6ewGMo6IvCg88sCQl/kv/j/q+1S/qhIVSlWZfyI06tRWwqIiPc0dltA9Vli+9u0mFgLVcvx2PO1VE+1W/40nbycRupczk0iamsre+BS3RVy/vNneyePDEwWUybjT4AAAAASUVORK5CYII=","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./app/Pages/Userside/mylibrary/page.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 









const page_page = ()=>{
    const [showModal, setShowModal] = (0,react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "  top-[-500px] rounded-3xl ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: " absolute ml-[460px] w-[1200px]",
                        src: bg1/* default */.Z,
                        alt: "bgimg"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " pt-10 pb-8",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: " ml-64 text-[#015464] text-3xl font-extrabold mt-32 ",
                                    children: "My Library"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " mt-8",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                        className: " w-[1660px] bg-[#14adad] bg-opacity-40 p-[1px]"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: " mt-4 mb-4 ml-64 text-[#015464] text-sm font-semibold",
                                        children: "Current Reading"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                        className: " absolute w-24 p-1 bg-[#015464] mt-[-2]  ml-64"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                        className: " w-[1660px] bg-[#14adad] bg-opacity-40 p-[1px]"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " mt-10 ml-[300px] gap-10 flex",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " absolute top-[530px] mt-52 w-[400px] left-[-200px] ",
                                src: img1["default"]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: " w-44",
                                        src: book,
                                        alt: "book-img"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: " text-sm mt-2 text-[#015464] font-bold",
                                        children: "King of Battle and Blood"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Staricon, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-xs mt-2 text-[#14adad]",
                                        children: "by Scarlett St.Clair"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-xs mt-2 text-[#14adad]",
                                        children: "Reas 47%"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: " bg-[#015464] p-2 text-white rounded px-3 mt-4",
                                        children: "Continue Reading"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: " w-44",
                                        src: book,
                                        alt: "book-img"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: " text-sm mt-2 text-[#015464] font-bold",
                                        children: "King of Battle and Blood"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Staricon, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-xs mt-2 text-[#14adad]",
                                        children: "by Scarlett St.Clair"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-xs mt-2 text-[#14adad]",
                                        children: "Reas 47%"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: " bg-[#015464] p-2 text-white rounded px-3 mt-4",
                                        children: "Continue Reading"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: " w-44",
                                        src: book,
                                        alt: "book-img"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: " text-sm mt-2 text-[#015464] font-bold",
                                        children: "King of Battle and Blood"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Staricon, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-xs mt-2 text-[#14adad]",
                                        children: "by Scarlett St.Clair"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-xs mt-2 text-[#14adad]",
                                        children: "Reas 47%"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: " bg-[#015464] p-2 text-white rounded px-3 mt-4",
                                        children: "Continue Reading"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: " w-44",
                                        src: book,
                                        alt: "book-img"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: " text-sm mt-2 text-[#015464] font-bold",
                                        children: "King of Battle and Blood"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Staricon, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-xs mt-2 text-[#14adad]",
                                        children: "by Scarlett St.Clair"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-xs mt-2 text-[#14adad]",
                                        children: "Reas 47%"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: " bg-[#015464] p-2 text-white rounded px-3 mt-4",
                                        children: "Continue Reading"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: " w-44",
                                        src: book,
                                        alt: "book-img"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: " text-sm mt-2 text-[#015464] font-bold",
                                        children: "King of Battle and Blood"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Staricon, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-xs mt-2 text-[#14adad]",
                                        children: "by Scarlett St.Clair"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-xs mt-2 text-[#14adad]",
                                        children: "Reas 47%"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: " bg-[#015464] p-2 text-white rounded px-3 mt-4",
                                        children: "Continue Reading"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " absolute left-[1500px] w-32",
                                src: Lefe1["default"],
                                alt: "Lefe-img"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: " mt-8",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: " mt-8",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                            className: " w-[1660px] bg-[#14adad] text-sm bg-opacity-40 p-[1px]"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: " mt-4 mb-4 ml-64 text-[#015464] text-sm font-bold",
                                            children: "Current Reading"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                            className: " absolute w-24 p-1 bg-[#015464] mt-[-2]  ml-64"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("btton", {
                                            className: " ml-10 text-[#015464] text-sm font-bold",
                                            children: "My Booksshelves"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                            className: " w-[1660px] bg-[#14adad] bg-opacity-40 p-[1px]"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: " mt-20 ml-[300px] gap-10 flex",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            className: " absolute top-[530px] mt-52 w-[400px] left-[-200px] ",
                                            src: img1["default"]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: " w-44",
                                                    src: book,
                                                    alt: "book-img"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: " text-sm mt-2 text-[#015464] font-bold",
                                                    children: "King of Battle and Blood"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(Staricon, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: " text-xs mt-2 text-[#14adad]",
                                                    children: "by Scarlett St.Clair"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: " w-44",
                                                    src: book,
                                                    alt: "book-img"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: " text-sm mt-2 text-[#015464] font-bold",
                                                    children: "King of Battle and Blood"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(Staricon, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: " text-xs mt-2 text-[#14adad]",
                                                    children: "by Scarlett St.Clair"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: " w-44",
                                                    src: book,
                                                    alt: "book-img"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: " text-sm mt-2 text-[#015464] font-bold",
                                                    children: "King of Battle and Blood"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(Staricon, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: " text-xs mt-2 text-[#14adad]",
                                                    children: "by Scarlett St.Clair"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: " w-44",
                                                    src: book,
                                                    alt: "book-img"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: " text-sm mt-2 text-[#015464] font-bold",
                                                    children: "King of Battle and Blood"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(Staricon, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: " text-xs mt-2 text-[#14adad]",
                                                    children: "by Scarlett St.Clair"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: " w-44",
                                                    src: Add,
                                                    alt: "Add-img"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: " bg-[#015464] py-2 px-8 mt-10 ml-7 rounded text-white",
                                                    onClick: ()=>setShowModal(true),
                                                    children: "+Add New"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            className: " absolute left-[100px] mt-[200px] w-32",
                                            src: Lefe1["default"],
                                            alt: "Lefe-img"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(addBook_page, {
                isVisivle: showModal,
                onClick: ()=>setShowModal(false)
            })
        ]
    });
};
/* harmony default export */ const mylibrary_page = (page_page);


/***/ }),

/***/ 5376:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Project\e-nool-frontend\app\Pages\Userside\mylibrary\page.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 2417:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Lefe1.7cd3c653.png","height":321,"width":164,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAfElEQVR42mNIOzBRzmdnCwcDEITu7mBkSN4/IS92b09Z8O52AQYQiNrbbZi4r29G5J4uPQYYSNjXZ5eyf6IfAwiUHJnFmnFgskzqgYnWmQcn2zLE7O1hSdrfXwI0UKjs6Gw2BhBIOzDJCSjIywADhYdnyBQdninCwMDAAAD7WCsf8H+m5wAAAABJRU5ErkJggg==","blurWidth":4,"blurHeight":8});

/***/ }),

/***/ 6315:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/bg1.3f5f09bf.png","height":1540,"width":1811,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAMAAAACh/xsAAAAS1BMVEV+xbN/xLGAw7B/w7F/w7CAwq9/xLF/xLF/xLF/xLF/xLF/xLF/xLF/xLF/xLF/xLF/xLGAxLGAxLB/xLF/xLCAw7B/w7CAw7CAw7B5UEk+AAAAGXRSTlMAAAAAAAABAwkNEhMUFRcYGRoaGhoaGhscitjNAwAAADxJREFUeNoVyMkRgDAMBMEVh7lBMMhy/pFS9LN1pfMAmr3FS62yacvgRmbdmhAaSr804p9yJuEyjUeS+wdrhgMxyWywdQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 4899:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/img1.9463f727.png","height":604,"width":505,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAMAAAAC2hU0AAAAUVBMVEUk6r4g6sUm374n3r8o3cEn3r4m3r8m3r4n3b8n3b4m3b4o274AAAAn3r8n3r4m3r8m3r4n3b8n3b4m3b4n3r8n3r4m3r8m3r4n3b8n3b4m3b81YMXeAAAAG3RSTlMAAAAAAAAAAAAAAAAAAQEBAQEBAQICAgICAgJi4TjxAAAAPUlEQVR42gVAARZAIAz9pDZDJquZ+x+0h3JbHYUgquRCKHWkqwuiLQe/Dss5ESlcse38gL/1bNmQrEf4PwFYlQLqj/kWbQAAAABJRU5ErkJggg==","blurWidth":7,"blurHeight":8});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [152,131,210], () => (__webpack_exec__(6131)));
module.exports = __webpack_exports__;

})();