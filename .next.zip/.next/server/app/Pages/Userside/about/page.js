(() => {
var exports = {};
exports.id = 535;
exports.ids = [535];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 9320:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'Pages',
        {
        children: [
        'Userside',
        {
        children: [
        'about',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 531)), "C:\\Project\\e-nool-frontend\\app\\Pages\\Userside\\about\\page.jsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9376)), "C:\\Project\\e-nool-frontend\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Project\\e-nool-frontend\\app\\Pages\\Userside\\about\\page.jsx"];

    

    const originalPathname = "/Pages/Userside/about/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/Pages/Userside/about/page","pathname":"/Pages/Userside/about","bundlePath":"app/Pages/Userside/about/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 6882:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 565));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5189));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2417));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7642));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8215));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4344));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9942));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8702));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4899));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3137));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4802));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4812));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6099));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2943));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 522));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6050));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7235));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4325));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7364))

/***/ }),

/***/ 531:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(4178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(2947);
// EXTERNAL MODULE: ./public/assets/aboutbg.png
var aboutbg = __webpack_require__(5632);
// EXTERNAL MODULE: ./public/assets/Leaf.png
var Leaf = __webpack_require__(7806);
;// CONCATENATED MODULE: ./public/assets/about1.png
/* harmony default export */ const about1 = ({"src":"/_next/static/media/about1.46c551e6.png","height":591,"width":480,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAYAAADaxo44AAAAt0lEQVR42mMAgamlLY4NtqF2DMjg/38GxjN1/ntP7N217dObpxO63JLVQ30YxBlAoL0gbMaeY6f+v3jx/v+Z3btezekqW8BQwcAgc+LYqd5b91/8f/Dq2493G6f+/zo5agbDsUkNC+6fPP7/xftfv569+PDj6cWL//eu27SUISixtX7X/nNvj5y5+P/l6y//j12693ViS28CAwNDnNq+Q1cCpy9b3n7jzpPiN68/B/79+1+UARcAAEIGYphU9r5UAAAAAElFTkSuQmCC","blurWidth":6,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/about2.png
/* harmony default export */ const about2 = ({"src":"/_next/static/media/about2.1a47e32a.png","height":132,"width":173,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAjklEQVR42mN4e+3uwjcXby1+e/O+87vbD8UZgODd3UeMDDDw9tYD4zcXbv5/dezSf6DCUAYgeH36KjMDMgDqjni570z+bYYGdgZ08ObybSYGIHi6Yi/Hq5NX2BiA4MWOE5JAjDDl/cOnTC/2nmF/vv24KFBCCoh1X2w/zsiADTzfcYIVqEAYiMWe7zghAAAI3krn4BvhyAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});
// EXTERNAL MODULE: ./public/assets/Lefe1.png
var Lefe1 = __webpack_require__(2758);
;// CONCATENATED MODULE: ./public/assets/grp1.png
/* harmony default export */ const grp1 = ({"src":"/_next/static/media/grp1.fd7b4dbe.png","height":496,"width":975,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAgklEQVR42mP4+/gLy/9nN5mSU0qZbj66w8gABJsmVzIdW7CSgwEErq+ZysOABB5urWEC0V8OXeEsqmgxZJjVtTpv08wF1cFtM6UPv3/BDZKc0rhUuiIzQ2tRb4MTw4RJuzqWLNjwcfOkWZvOHbqy/PKJh1M3TuhbsmbOqhePZnUbAAAMeDk4Rj5vWQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});
// EXTERNAL MODULE: ./public/assets/Ellipse.png
var Ellipse = __webpack_require__(6385);
// EXTERNAL MODULE: ./public/assets/img1.png
var img1 = __webpack_require__(1152);
// EXTERNAL MODULE: ./public/assets/Lefe2.png
var Lefe2 = __webpack_require__(9995);
;// CONCATENATED MODULE: ./public/assets/grid.png
/* harmony default export */ const grid = ({"src":"/_next/static/media/grid.20c1c788.png","height":81,"width":81,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAApElEQVR42g3FMS5EAQAFwHnrRyGi0uhEolcoKFQ62c4BnMAJtlarJYp1BzoX2JYTyIpEKCk2wfOLyWS2eID9tNdYR/BdLq+OpssJYCp5HT2PnkbvOIMhetGaVtbwSyckkb3Z4v5zUHMi6RseAWet7dThpImwIrdlk3xobwT8TbTEim6EgZ5iHT/IkERra+yAvKhl4xiD0YA7et46oTsY1C6+GvN/KPY8Yr4cvM4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/arrowicon.png
/* harmony default export */ const arrowicon = ({"src":"/_next/static/media/arrowicon.01fec931.png","height":60,"width":53,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAQAAACfDS2NAAAAYUlEQVR42g3BMQqCUAAA0EdDU0M0FEF7HaVTBG0NReAhPIGDB3DU4U8KCi6COngGZ2+h70FiUmsMMq46e7DTwAOROwI/f1/B4iznvX0JZicFPPFxQ+CidwQHLcRGlVInXQH+4hW7YzfkGwAAAABJRU5ErkJggg==","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img2.png
/* harmony default export */ const img2 = ({"src":"/_next/static/media/img2.e297ec9a.png","height":76,"width":183,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAQAAAAEwYbDAAAALElEQVR42l3ByQnAIAAAsPTRVhAURPDANdx/Nf8mPJJm6KofpiJ4faJlu+QDIVQBHX6xRQIAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/assets/img3.png
/* harmony default export */ const img3 = ({"src":"/_next/static/media/img3.d1af7064.png","height":76,"width":183,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAQAAAAEwYbDAAAAKUlEQVR42l3BwQkAEAAAwPMhJQ8KyRj2n83fnU9j67IoKY5LUA3L1EUeFOQBH2MAAncAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/assets/img4.png
/* harmony default export */ const img4 = ({"src":"/_next/static/media/img4.3fb82255.png","height":91,"width":91,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAsUlEQVR42h3NsQrCMBSF4aubLvYN1EkXca+Cs4OogyCIigpOFYqdbG4dHVx9C+fkHZK36p8WPhrOPbkR413LBCfoaXBXE+zJeNuBoC0abJSiIjirtxn/LcVE4keQcHOHKeGHTW+yCaV5U+DQxZgNM/zVux+FC+dDU+DmGkek8W0GI9xxQ19YWUYMH5QGhEsoz73YlAuDAhmeFFaEe4YVpRKF8OaX0FDYEAiGFHMUGuyiBjwzioE0vcQ+AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/Mask Group 5.png
/* harmony default export */ const Mask_Group_5 = ({"src":"/_next/static/media/Mask Group 5.2da5bca9.png","height":228,"width":230,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA2ElEQVR42h3GIU8CYQDG8f/z3h3IpiTEwZinYzNZSH4BirP6DQ1mi9VgslgszgSTyVTcbhjEe7n3cfOXfnpdvM2AEsnVy72yTUX39NyEQjjNc3BZFC2/Lxe6ub4ieMNFf6LB6Ngx1mUuyZb0dHfL5XRKahLPjw8MD8cSOEhBqdnSjj/QCMeG3SInOYGkYJsQMk4mZ1TLD9bLTwblEWCwCfwPiv6QEL8JrYzOwQiSkXAuELb3eiOt9sdsszbtbo+UGgPS6ms9Cwqlssyx/lVdR3Y6HeOkGOv5H6k2YVJ63JLVAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/group.png
/* harmony default export */ const group = ({"src":"/_next/static/media/group.db44d9ba.png","height":483,"width":707,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAsElEQVR4nAGlAFr/AaSjkngXCwZDRdjzaCa5yKIpJRXzsTs2ZpDd2pzm/gDBAZOalv0wDwkCjN/puXwE1kTO8Qv+ZwEYvJLw7EnS+v3/AauEh7H09fdOIhYRRiMBraPl7fb6V9ZBW3oV6cIhFhW5AXpIN4nc8Pt2OcjOCwh2c5gPFRVGKg7VGC8RB8gA/f7oAQAhO2EYA/iN59vMEm2fy2fk6eVfCtyuRpE379Hn8vb+PoFSsufWJFEAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/rectangle2.png
/* harmony default export */ const rectangle2 = ({"src":"/_next/static/media/rectangle2.793e2462.png","height":599,"width":523,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAIBAMAAADHKvg1AAAAFVBMVEV7yLR8ybV7ybV7ybR8yLV7yLV7yLSrC1CiAAAAAXRSTlP6HY7DZAAAAC5JREFUeNpjYBQUZGBwU1FzYAhSVA1gSFNUS2BINgQSacZmCQzCgmICDIyGigwAdXwFz6+PhKoAAAAASUVORK5CYII=","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/group2.png
/* harmony default export */ const group2 = ({"src":"/_next/static/media/group2.dc975646.png","height":415,"width":483,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA8klEQVR4nAHnABj/Adf/+QHqxMb/sAj1cg3/An78/f0P+/j5y/Hl6WSaXGvYAaXn0AD2z9167w0Ghdzq6QD47O/+GCQgAv4A/+PgydJPAQB3TiTgb5Xb8fb1AMHQzv5NMDcCqeXW++j9+AUE/P2pAWG7p59xHjFg/AH//abh0gNC/A8A5x/9/9bt9QEC+QHXAYDQr/j18fsH//8DAPH//AAUAe0AGyEO/fH1BgPv5wW6AZPVs+kS+w0WAP8E//0B/wEAEfQA/wP7AO7m8wDayO9IAT9uZ4+QX2dwKCco/un17uvn/OsKIwgcDau4sO9rW2UtlPCBT4RuXmcAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/assets/group3.png
/* harmony default export */ const group3 = ({"src":"/_next/static/media/group3.bf27f4ca.png","height":417,"width":451,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA40lEQVR42hXOq04DQRiG4e+fQ3czXdpQCw5QCG6A4PBwAwgU90ACqvcACgGoOgIe05BUgShV69qkTVY0nXQ7u3Pq9jWPfQlND6NB1nCSdTup8+7O1faGiF4A3FJ//HlR6fKdJ/LAWUt2UyHb7yKEACK6YtH6frqnDstiFYePr5j+/IcIOKPXaLoUujYj5vm5UjK+PT8htwv2sZzEjmqDgQK77p0OjlqqEGrDv8NfHPMcPWWYSCxyo79Im3U5m89E5ax03KNKPIbFL5AwnKXH9+SDD9Y5hEZOHFJILOvVbpK1W4q2V4lqrjGtJV4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./app/Pages/Userside/about/page.jsx






















function About() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: " relative h-[600px]",
                src: aboutbg/* default */.Z
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " flex justify-between top-48 absolute ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: " absolute ml-0 w-[65px]",
                        src: Leaf/* default */.Z,
                        alt: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: " absolute top-14 left-[300px] w-[90px] h-[102px]",
                        src: about2,
                        alt: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: " ml-[350px] h-[200]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: " left-56 top-[130px] w-[350px]",
                            src: about1,
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " ml-52",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " absolute ml-[570px] w-28 mt-0",
                                src: Lefe1/* default */.Z,
                                alt: ""
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: " text-[#015464] text-lg font-bold top-[251px] left-[965px] w-[143px] h-[16px]",
                                children: "WHO WE ARE"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " text-[#015464] font-extrabold text-4xl mt-8",
                                children: "About ENOOL"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: " text-[#015464] mt-10 text-sm font-medium left-[965px] w-[500px] h-[146px]",
                                children: "At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: " bg-[#14adad] opacity-1 mt-8 p-2 px-5 rounded-3xl text-white ",
                                children: "Get Started"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " flex",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " absolute top-[530px] left-[-280px] w-[400px]",
                                src: img1/* default */.Z,
                                alt: ""
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " ml-10 mt-48",
                                src: Ellipse/* default */.Z,
                                alt: ""
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex mt-20 p-0",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: " ml-20 font-extrabold text-3xl text-[#015464]",
                                        children: "Our Story"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                        className: " bg-[#14adad] w-[242px] ml-[80px] mt-3 p-0.5 opacity-0.7 rounded-sm"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " font-medium text-[#015464] mt-8 w-[600px] text-ms h-[80px] ml-20",
                                        children: "At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " w-[650px] ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: " ml-28",
                                    src: grp1,
                                    alt: ""
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " relative bg-[#015464] h-[500px] object-fill",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "  m-0",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: " w-52",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " absolute mt-36 left-10 w-28",
                                src: Lefe2/* default */.Z,
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: " text-white text-center p-20",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: " font-extrabold text-3xl",
                                    children: "Why subscribe for Enool?"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: " p-5 text-xs font-light",
                                    children: "Why subscribe for Enool?"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: " flex justify-center",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-col ml-32 h-[243px] rounded-lg border-black shadow-md w-[400px] outline  m-6 overflow-hidden sm:w-52",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: " mt-5 m-auto",
                                                    src: grid,
                                                    alt: "",
                                                    className: "h-20 m-6"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: " text-white mt-0 p-2 ",
                                                    children: "01.Learn"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: " text-xs font-thin p-2",
                                                    children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-col ml-24 h-[243px] rounded-lg border-black shadow-md w-[400px] outline  m-6 overflow-hidden sm:w-52",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: " mt-5 m-auto",
                                                    src: grid,
                                                    alt: "",
                                                    className: "h-20 m-6"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: " text-white mt-0 p-2 ",
                                                    children: "01.Learn"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: " text-xs font-thin p-2",
                                                    children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-col ml-24 h-[243px] rounded-lg border-black shadow-md w-[400px] outline  m-6 overflow-hidden sm:w-52",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: " mt-5 m-auto",
                                                    src: grid,
                                                    alt: "",
                                                    className: "h-20 m-6"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: " text-white mt-0 p-2 ",
                                                    children: "01.Learn"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: " text-xs font-thin p-2",
                                                    children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            className: " w-[563px] absolute top-[-190px] left-[1490px]",
                                            src: img1/* default */.Z,
                                            alt: ""
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " bg-white justify-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " mt-14 font-medium text-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " text-[#015464] font-extrabold text-2xl",
                                children: "Start your Reading Journey Today!"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: " text-[#14adad] text-sm mt-3",
                                children: "12,000+ Unique Books"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex mt-20 justify-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: " ml-28 py-8 px-8 rounded-[500px] bg-[#14adad]",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            className: "  ",
                                            src: arrowicon,
                                            alt: ""
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: " text-[#14adad] text-xs ml-32 p-1 font-semibold",
                                        children: "Log In & Signup"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " mt-5 ml-20 h-20",
                                src: img2,
                                alt: ""
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: " ml-28 py-8 px-8 rounded-[500px] bg-[#14adad]",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            className: "  ",
                                            src: arrowicon,
                                            alt: ""
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: " text-[#14adad] text-xs ml-32 p-1 font-semibold",
                                        children: "Subscribe"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " ml-20 mt-5 h-20",
                                src: img3,
                                alt: ""
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: " ml-28 py-8 px-8 rounded-[500px] bg-[#14adad]",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            className: "  ",
                                            src: arrowicon,
                                            alt: ""
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: " text-[#14adad] text-xs ml-24 p-1 font-semibold",
                                        children: "Browse & Start Reading"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " bg-white mt-20",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: " text-center text-[#015464]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: " font-bold text-2xl",
                            children: "Our Core Value"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex justify-center mt-10",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex  flex-col  ml-24 h-[270px] rounded-lg border-white  shadow-md m-6 overflow-hidden sm:w-52",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: " mt-5 ml-14 w-16",
                                        src: img4,
                                        alt: "",
                                        className: "h-20 m-6"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: " text-black mt-0 p-2 font-semibold ",
                                        children: "Our Mission"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-black text-xs p-2 ",
                                        children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col ml-24 h-[270px] rounded-lg border-white shadow-md w-[400px]   m-6 overflow-hidden sm:w-52",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: " mt-5 ml-14 w-16",
                                        src: img4,
                                        alt: "",
                                        className: "h-20 m-6"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: " text-black mt-0 p-2 font-semibold ",
                                        children: "Our Vission"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-black text-xs p-2",
                                        children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col ml-24 h-[270px]  rounded-lg border-white shadow-md w-[400px] m-6 overflow-hidden sm:w-52",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: " mt-5 ml-14 w-16",
                                        src: img4,
                                        alt: "",
                                        className: "h-20 m-6"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: " text-black mt-0 p-2 font-semibold ",
                                        children: "Our Passion"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-black text-xs p-2",
                                        children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " bg-white mt-20",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " text-center font-medium",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " text-[#015464] text-2xl font-extrabold",
                                children: "Meet our awesome and Enool Team"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: " text-[#14adad] text-sm mt-4",
                                children: [
                                    '"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..." ',
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    '"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."'
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex justify-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col ml-32 h-[270px]  rounded-3xl border-white shadow-md w-[400px] m-6 overflow-hidden sm:w-52",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: " w-40 m-auto mt-5",
                                        src: Mask_Group_5,
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        className: " mb-1 text-center font-extrabold text-[#015464]",
                                        children: "Shalini"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-sm text-[#14adad] text-center mb-5",
                                        children: "Director"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col  h-[270px]  rounded-3xl border-white shadow-md w-[400px] m-6 overflow-hidden sm:w-52",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: " w-40 m-auto mt-5",
                                        src: Mask_Group_5,
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        className: " mb-1 text-center font-extrabold text-[#015464]",
                                        children: "Shalini"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-sm text-[#14adad] text-center mb-5",
                                        children: "Director"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col h-[270px]  rounded-3xl border-white shadow-md w-[400px] m-6 overflow-hidden sm:w-52",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: " w-40 m-auto mt-5",
                                        src: Mask_Group_5,
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        className: " mb-1 text-center font-extrabold text-[#015464]",
                                        children: "Shalini"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-sm text-[#14adad] text-center mb-5",
                                        children: "Director"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col h-[270px]  rounded-3xl border-white shadow-md w-[400px] m-6 overflow-hidden sm:w-52",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: " w-40 m-auto mt-5",
                                        src: Mask_Group_5,
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        className: " mb-1 text-center font-extrabold text-[#015464]",
                                        children: "Shalini"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-sm text-[#14adad] text-center mb-5",
                                        children: "Director"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " bg-white flex mt-20 mb-48 pl-24",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " mt-40 ml-32 pl-10",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                className: " text-[#015464] text-3xl text-start font-bold",
                                children: [
                                    "Learn new skills when ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    " and where you Reading."
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: " text-[#14adad] text-xs text-start pt-3",
                                children: [
                                    '"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet,',
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    '"There is no one who loves pain itself, who seeks after it and wants'
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: " bg-[#015464] opacity-1 items-start mt-8 p-2 px-5 rounded text-white ",
                                children: "Subsribe Now"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " pl-32 ml-32 ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " absolute h-[399px] w-[423px] ",
                                src: rectangle2
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " ml-32 absolute left-[725px] w-[490px] mt-[65px]",
                                src: group
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " bg-white flex mt-20 mb-48 ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: " pl-32 ml-32 ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: " relative h-[399px] w-[423px] ",
                            src: group2
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " pl-32 ml-20 items-start",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " text-[#015464] font-extrabold text-3xl ml-4 mt-28",
                                children: "Become an Publisher"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: " p-3 text-[#14adad] text-sm",
                                children: [
                                    '"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet,',
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    '"There is no one who loves pain itself, who seeks after it and wants'
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: " bg-[#015464] opacity-1 items-start mt-8 ml-5 p-2 px-5 rounded text-white ",
                                children: "Subsribe Now"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " bg-white flex mt-20 mb-32 pl-24",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " mt-40 ml-32 pl-10",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " text-[#015464] text-3xl text-start font-bold",
                                children: "Become an Author."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: " text-[#14adad] text-xs text-start pt-3",
                                children: [
                                    '"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet,',
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    '"There is no one who loves pain itself, who seeks after it and wants'
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: " bg-[#015464] opacity-1 items-start mt-8 p-2 px-5 rounded text-white ",
                                children: "Subsribe Now"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: " pl-32 ml-32 ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: " absolute h-[399px] w-[423px] ",
                            src: group3
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " bg-white items-center mb-28",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: " text-center text-3xl",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: " font-extrabold text-[#015464]",
                            children: "Enool by the Numbers"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex mt-20 ml-[400px]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " text-center ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: " text-[#14adad] text-sm",
                                        children: "Readers"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: " text-6xl font-bold text-[#015464] ",
                                        children: "300k"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " ml-52 text-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: " text-[#14adad] text-sm",
                                        children: "Publisher"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: " text-6xl font-bold text-[#015464] ",
                                        children: "700k"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " ml-52 text-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: " text-[#14adad] text-sm",
                                        children: "Books"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: " text-6xl font-bold text-[#015464] ",
                                        children: "20k"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " mb-20 mt-32 bg-white font-medium",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " mt-9 text-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: " text-[#14adad] text-sm",
                                children: "Newsletter"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: " text-[#015464] mt-4 font-extrabold text-3xl",
                                children: " Do You wan to get splecial News?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " ml-[650px]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                className: " bg-gray-200 p-2 rounded px-4 ",
                                type: "email",
                                placeholder: "Drop your Email"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: " bg-[#14adad] opacity-1 items-start mt-8 ml-4 p-2 px-5 rounded-2xl text-white ",
                                children: "Subsribe Now"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const page = (About);


/***/ }),

/***/ 2758:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Lefe1.7cd3c653.png","height":321,"width":164,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAfElEQVR42mNIOzBRzmdnCwcDEITu7mBkSN4/IS92b09Z8O52AQYQiNrbbZi4r29G5J4uPQYYSNjXZ5eyf6IfAwiUHJnFmnFgskzqgYnWmQcn2zLE7O1hSdrfXwI0UKjs6Gw2BhBIOzDJCSjIywADhYdnyBQdninCwMDAAAD7WCsf8H+m5wAAAABJRU5ErkJggg==","blurWidth":4,"blurHeight":8});

/***/ }),

/***/ 2417:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Lefe1.7cd3c653.png","height":321,"width":164,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAfElEQVR42mNIOzBRzmdnCwcDEITu7mBkSN4/IS92b09Z8O52AQYQiNrbbZi4r29G5J4uPQYYSNjXZ5eyf6IfAwiUHJnFmnFgskzqgYnWmQcn2zLE7O1hSdrfXwI0UKjs6Gw2BhBIOzDJCSjIywADhYdnyBQdninCwMDAAAD7WCsf8H+m5wAAAABJRU5ErkJggg==","blurWidth":4,"blurHeight":8});

/***/ }),

/***/ 9995:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Lefe2.c0892c82.png","height":321,"width":164,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAf0lEQVR42mMI3d3ByAAEvrtaONIOTJRjAIHg3e1CsXt7ypP3T8hhAIHIPV2Gifv6ZkTu6dZnAIHU/RP9E/b12TCAQObByXapByZaZRycLFN6ZDYLQ/nROWxhezpFkvb3l4Tv6WRmAAGgYfzpByY5MsBA0eGZooWHZ0gzMDAwAADC9iskupzWpgAAAABJRU5ErkJggg==","blurWidth":4,"blurHeight":8});

/***/ }),

/***/ 8702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Lefe2.c0892c82.png","height":321,"width":164,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAf0lEQVR42mMI3d3ByAAEvrtaONIOTJRjAIHg3e1CsXt7ypP3T8hhAIHIPV2Gifv6ZkTu6dZnAIHU/RP9E/b12TCAQObByXapByZaZRycLFN6ZDYLQ/nROWxhezpFkvb3l4Tv6WRmAAGgYfzpByY5MsBA0eGZooWHZ0gzMDAwAADC9iskupzWpgAAAABJRU5ErkJggg==","blurWidth":4,"blurHeight":8});

/***/ }),

/***/ 522:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Mask Group 5.2da5bca9.png","height":228,"width":230,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA2ElEQVR42h3GIU8CYQDG8f/z3h3IpiTEwZinYzNZSH4BirP6DQ1mi9VgslgszgSTyVTcbhjEe7n3cfOXfnpdvM2AEsnVy72yTUX39NyEQjjNc3BZFC2/Lxe6ub4ieMNFf6LB6Ngx1mUuyZb0dHfL5XRKahLPjw8MD8cSOEhBqdnSjj/QCMeG3SInOYGkYJsQMk4mZ1TLD9bLTwblEWCwCfwPiv6QEL8JrYzOwQiSkXAuELb3eiOt9sdsszbtbo+UGgPS6ms9Cwqlssyx/lVdR3Y6HeOkGOv5H6k2YVJ63JLVAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 7642:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/about1.46c551e6.png","height":591,"width":480,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAYAAADaxo44AAAAt0lEQVR42mMAgamlLY4NtqF2DMjg/38GxjN1/ntP7N217dObpxO63JLVQ30YxBlAoL0gbMaeY6f+v3jx/v+Z3btezekqW8BQwcAgc+LYqd5b91/8f/Dq2493G6f+/zo5agbDsUkNC+6fPP7/xftfv569+PDj6cWL//eu27SUISixtX7X/nNvj5y5+P/l6y//j12693ViS28CAwNDnNq+Q1cCpy9b3n7jzpPiN68/B/79+1+UARcAAEIGYphU9r5UAAAAAElFTkSuQmCC","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 8215:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/about2.1a47e32a.png","height":132,"width":173,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAjklEQVR42mN4e+3uwjcXby1+e/O+87vbD8UZgODd3UeMDDDw9tYD4zcXbv5/dezSf6DCUAYgeH36KjMDMgDqjni570z+bYYGdgZ08ObybSYGIHi6Yi/Hq5NX2BiA4MWOE5JAjDDl/cOnTC/2nmF/vv24KFBCCoh1X2w/zsiADTzfcYIVqEAYiMWe7zghAAAI3krn4BvhyAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 4802:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/arrowicon.01fec931.png","height":60,"width":53,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAQAAACfDS2NAAAAYUlEQVR42g3BMQqCUAAA0EdDU0M0FEF7HaVTBG0NReAhPIGDB3DU4U8KCi6COngGZ2+h70FiUmsMMq46e7DTwAOROwI/f1/B4iznvX0JZicFPPFxQ+CidwQHLcRGlVInXQH+4hW7YzfkGwAAAABJRU5ErkJggg==","blurWidth":7,"blurHeight":8});

/***/ }),

/***/ 3137:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/grid.20c1c788.png","height":81,"width":81,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAApElEQVR42g3FMS5EAQAFwHnrRyGi0uhEolcoKFQ62c4BnMAJtlarJYp1BzoX2JYTyIpEKCk2wfOLyWS2eID9tNdYR/BdLq+OpssJYCp5HT2PnkbvOIMhetGaVtbwSyckkb3Z4v5zUHMi6RseAWet7dThpImwIrdlk3xobwT8TbTEim6EgZ5iHT/IkERra+yAvKhl4xiD0YA7et46oTsY1C6+GvN/KPY8Yr4cvM4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 6050:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/group.db44d9ba.png","height":483,"width":707,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAsElEQVR4nAGlAFr/AaSjkngXCwZDRdjzaCa5yKIpJRXzsTs2ZpDd2pzm/gDBAZOalv0wDwkCjN/puXwE1kTO8Qv+ZwEYvJLw7EnS+v3/AauEh7H09fdOIhYRRiMBraPl7fb6V9ZBW3oV6cIhFhW5AXpIN4nc8Pt2OcjOCwh2c5gPFRVGKg7VGC8RB8gA/f7oAQAhO2EYA/iN59vMEm2fy2fk6eVfCtyuRpE379Hn8vb+PoFSsufWJFEAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 7235:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/group2.dc975646.png","height":415,"width":483,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA8klEQVR4nAHnABj/Adf/+QHqxMb/sAj1cg3/An78/f0P+/j5y/Hl6WSaXGvYAaXn0AD2z9167w0Ghdzq6QD47O/+GCQgAv4A/+PgydJPAQB3TiTgb5Xb8fb1AMHQzv5NMDcCqeXW++j9+AUE/P2pAWG7p59xHjFg/AH//abh0gNC/A8A5x/9/9bt9QEC+QHXAYDQr/j18fsH//8DAPH//AAUAe0AGyEO/fH1BgPv5wW6AZPVs+kS+w0WAP8E//0B/wEAEfQA/wP7AO7m8wDayO9IAT9uZ4+QX2dwKCco/un17uvn/OsKIwgcDau4sO9rW2UtlPCBT4RuXmcAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 7364:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/group3.bf27f4ca.png","height":417,"width":451,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA40lEQVR42hXOq04DQRiG4e+fQ3czXdpQCw5QCG6A4PBwAwgU90ACqvcACgGoOgIe05BUgShV69qkTVY0nXQ7u3Pq9jWPfQlND6NB1nCSdTup8+7O1faGiF4A3FJ//HlR6fKdJ/LAWUt2UyHb7yKEACK6YtH6frqnDstiFYePr5j+/IcIOKPXaLoUujYj5vm5UjK+PT8htwv2sZzEjmqDgQK77p0OjlqqEGrDv8NfHPMcPWWYSCxyo79Im3U5m89E5ax03KNKPIbFL5AwnKXH9+SDD9Y5hEZOHFJILOvVbpK1W4q2V4lqrjGtJV4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 4344:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/grp1.fd7b4dbe.png","height":496,"width":975,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAgklEQVR42mP4+/gLy/9nN5mSU0qZbj66w8gABJsmVzIdW7CSgwEErq+ZysOABB5urWEC0V8OXeEsqmgxZJjVtTpv08wF1cFtM6UPv3/BDZKc0rhUuiIzQ2tRb4MTw4RJuzqWLNjwcfOkWZvOHbqy/PKJh1M3TuhbsmbOqhePZnUbAAAMeDk4Rj5vWQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 4812:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/img2.e297ec9a.png","height":76,"width":183,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAQAAAAEwYbDAAAALElEQVR42l3ByQnAIAAAsPTRVhAURPDANdx/Nf8mPJJm6KofpiJ4faJlu+QDIVQBHX6xRQIAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 6099:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/img3.d1af7064.png","height":76,"width":183,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAQAAAAEwYbDAAAAKUlEQVR42l3BwQkAEAAAwPMhJQ8KyRj2n83fnU9j67IoKY5LUA3L1EUeFOQBH2MAAncAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 2943:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/img4.3fb82255.png","height":91,"width":91,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAsUlEQVR42h3NsQrCMBSF4aubLvYN1EkXca+Cs4OogyCIigpOFYqdbG4dHVx9C+fkHZK36p8WPhrOPbkR413LBCfoaXBXE+zJeNuBoC0abJSiIjirtxn/LcVE4keQcHOHKeGHTW+yCaV5U+DQxZgNM/zVux+FC+dDU+DmGkek8W0GI9xxQ19YWUYMH5QGhEsoz73YlAuDAhmeFFaEe4YVpRKF8OaX0FDYEAiGFHMUGuyiBjwzioE0vcQ+AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 4325:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/rectangle2.793e2462.png","height":599,"width":523,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAIBAMAAADHKvg1AAAAFVBMVEV7yLR8ybV7ybV7ybR8yLV7yLV7yLSrC1CiAAAAAXRSTlP6HY7DZAAAAC5JREFUeNpjYBQUZGBwU1FzYAhSVA1gSFNUS2BINgQSacZmCQzCgmICDIyGigwAdXwFz6+PhKoAAAAASUVORK5CYII=","blurWidth":7,"blurHeight":8});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [152,131,210,349,61], () => (__webpack_exec__(9320)));
module.exports = __webpack_exports__;

})();