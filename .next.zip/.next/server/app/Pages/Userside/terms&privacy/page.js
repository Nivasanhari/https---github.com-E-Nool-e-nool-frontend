(() => {
var exports = {};
exports.id = 794;
exports.ids = [794];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 5391:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'Pages',
        {
        children: [
        'Userside',
        {
        children: [
        'terms&privacy',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3944)), "C:\\Project\\e-nool-frontend\\app\\Pages\\Userside\\terms&privacy\\page.jsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9376)), "C:\\Project\\e-nool-frontend\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Project\\e-nool-frontend\\app\\Pages\\Userside\\terms&privacy\\page.jsx"];

    

    const originalPathname = "/Pages/Userside/terms&privacy/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/Pages/Userside/terms&privacy/page","pathname":"/Pages/Userside/terms&privacy","bundlePath":"app/Pages/Userside/terms&privacy/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 9583:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 565));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5189));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2417));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9942));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8702));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4899));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7063));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 882))

/***/ }),

/***/ 3944:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(4178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(2947);
// EXTERNAL MODULE: ./public/assets/Leaf.png
var Leaf = __webpack_require__(7806);
;// CONCATENATED MODULE: ./public/assets/privacy policy.png
/* harmony default export */ const privacy_policy = ({"src":"/_next/static/media/privacy policy.3ea311e8.png","height":200,"width":1375,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABAQMAAADZzn0AAAAABlBMVEUATmIATmIezQKQAAAAAnRSTlMEBWKV/LMAAAANSURBVHjaAQIA/f8ApgCoAKdHFihtAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":1});
// EXTERNAL MODULE: ./public/assets/aboutbg.png
var aboutbg = __webpack_require__(5632);
// EXTERNAL MODULE: ./public/assets/img1.png
var img1 = __webpack_require__(1152);
// EXTERNAL MODULE: ./public/assets/Ellipse.png
var Ellipse = __webpack_require__(6385);
// EXTERNAL MODULE: ./public/assets/Lefe1.png
var Lefe1 = __webpack_require__(2758);
// EXTERNAL MODULE: ./public/assets/terms.png
var terms = __webpack_require__(7386);
// EXTERNAL MODULE: ./public/assets/Lefe2.png
var Lefe2 = __webpack_require__(9995);
;// CONCATENATED MODULE: ./app/Pages/Userside/terms&privacy/page.jsx











const privacy = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " mb-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: "  h-[400px] top-[-83px]",
                        src: aboutbg/* default */.Z
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex justify-between top-48 absolute ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " ml-0  h-60 mt-[w-89px]",
                                src: Leaf/* default */.Z,
                                alt: ""
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " ml-[200px]",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: " absolute top-20 w-[800px] left-[280px]",
                                        src: privacy_policy
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: " text-[#015464] mt-52 text-3xl font-extrabold top-[351px]  h-[16px]",
                                        children: "Privacy Policy"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " ml-[200px] h-[180] ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: " ml-[80px] top-[130px] w-[500px]",
                                    src: terms/* default */.Z,
                                    alt: ""
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: " absolute left-[1200px] top-24 w-24 ",
                        src: Lefe1/* default */.Z,
                        alt: ""
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: " absolute left-7 mt-[330px] w-24",
                src: Ellipse/* default */.Z,
                alt: ""
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: " absolute top-[450px] w-[400px] left-[-200px]",
                src: img1/* default */.Z
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " mt-38 mb-24",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " bg-white",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " ml-[290px] text-[#015464] font-semibold text-2xl pb-5",
                                children: "As of April 07th,2023"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: " ml-[290px] w-[700px] text-[#14adad] text-xs",
                                children: "Lorem Ipsum је једноставно модел текста који се користи у штампарској и словослагачкој индустрији. Lorem ipsum је био стандард за модел текста још од 1500. године, када је непознати штампар узео кутију са словима и сложио их како би направио узорак књиге. Не само што је овај модел опстао пет векова, него је чак почео да се користи и у електронским медијима, непроменивши се."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " mt-9 bg-white",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " ml-[290px] text-[#015464] font-semibold text-2xl pb-5",
                                children: "As of April 07th,2023"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: " ml-[290px] w-[700px] text-[#14adad] text-xs",
                                children: "Lorem Ipsum је једноставно модел текста који се користи у штампарској и словослагачкој индустрији. Lorem ipsum је био стандард за модел текста још од 1500. године, када је непознати штампар узео кутију са словима и сложио их како би направио узорак књиге. Не само што је овај модел опстао пет векова, него је чак почео да се користи и у електронским медијима, непроменивши се."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " mt-9 bg-white",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " ml-[290px] text-[#015464] font-semibold text-2xl pb-5",
                                children: "As of April 07th,2023"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: " ml-[290px] w-[700px] text-[#14adad] text-xs",
                                children: "Lorem Ipsum је једноставно модел текста који се користи у штампарској и словослагачкој индустрији. Lorem ipsum је био стандард за модел текста још од 1500. године, када је непознати штампар узео кутију са словима и сложио их како би направио узорак књиге. Не само што је овај модел опстао пет векова, него је чак почео да се користи и у електронским медијима, непроменивши се."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " mt-9 bg-white",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " ml-[290px] text-[#015464] font-semibold text-2xl pb-5",
                                children: "As of April 07th,2023"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: " ml-[290px] w-[700px] text-[#14adad] text-xs",
                                children: "Lorem Ipsum је једноставно модел текста који се користи у штампарској и словослагачкој индустрији. Lorem ipsum је био стандард за модел текста још од 1500. године, када је непознати штампар узео кутију са словима и сложио их како би направио узорак књиге. Не само што је овај модел опстао пет векова, него је чак почео да се користи и у електронским медијима, непроменивши се."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " mt-9 bg-white",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " ml-[290px] text-[#015464] font-semibold text-2xl pb-5",
                                children: "As of April 07th,2023"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: " ml-[290px] w-[700px] text-[#14adad] text-xs",
                                children: "Lorem Ipsum је једноставно модел текста који се користи у штампарској и словослагачкој индустрији. Lorem ipsum је био стандард за модел текста још од 1500. године, када је непознати штампар узео кутију са словима и сложио их како би направио узорак књиге. Не само што је овај модел опстао пет векова, него је чак почео да се користи и у електронским медијима, непроменивши се."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " mt-9 bg-white",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " ml-[290px] text-[#015464] font-semibold text-2xl pb-5",
                                children: "As of April 07th,2023"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: " ml-[290px] w-[700px] text-[#14adad] text-xs",
                                children: "Lorem Ipsum је једноставно модел текста који се користи у штампарској и словослагачкој индустрији. Lorem ipsum је био стандард за модел текста још од 1500. године, када је непознати штампар узео кутију са словима и сложио их како би направио узорак књиге. Не само што је овај модел опстао пет векова, него је чак почео да се користи и у електронским медијима, непроменивши се."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " mt-9 bg-white",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " ml-[290px] text-[#015464] font-semibold text-2xl pb-5",
                                children: "As of April 07th,2023"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: " ml-[290px] w-[700px] text-[#14adad] text-xs",
                                children: "Lorem Ipsum је једноставно модел текста који се користи у штампарској и словослагачкој индустрији. Lorem ipsum је био стандард за модел текста још од 1500. године, када је непознати штампар узео кутију са словима и сложио их како би направио узорак књиге. Не само што је овај модел опстао пет векова, него је чак почео да се користи и у електронским медијима, непроменивши се."
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: " absolute top-[900px] left-[1000px] w-[100px]",
                        src: Lefe2/* default */.Z,
                        alt: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: " absolute left-[1190px] top-[1350px] w-24",
                        src: Ellipse/* default */.Z
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: " absolute top-[1010px] left-[1030px] w-[350px]",
                        src: img1/* default */.Z,
                        alt: ""
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const page = (privacy);


/***/ }),

/***/ 882:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/privacy policy.3ea311e8.png","height":200,"width":1375,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABAQMAAADZzn0AAAAABlBMVEUATmIATmIezQKQAAAAAnRSTlMEBWKV/LMAAAANSURBVHjaAQIA/f8ApgCoAKdHFihtAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":1});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [152,131,210,349,61,831], () => (__webpack_exec__(5391)));
module.exports = __webpack_exports__;

})();