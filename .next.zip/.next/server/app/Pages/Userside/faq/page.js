(() => {
var exports = {};
exports.id = 286;
exports.ids = [286];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 7079:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'Pages',
        {
        children: [
        'Userside',
        {
        children: [
        'faq',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5091)), "C:\\Project\\e-nool-frontend\\app\\Pages\\Userside\\faq\\page.jsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9376)), "C:\\Project\\e-nool-frontend\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Project\\e-nool-frontend\\app\\Pages\\Userside\\faq\\page.jsx"];

    

    const originalPathname = "/Pages/Userside/faq/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/Pages/Userside/faq/page","pathname":"/Pages/Userside/faq","bundlePath":"app/Pages/Userside/faq/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 2000:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 565));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5189));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9942));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8702));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4899));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5915));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9925));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7234));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4745))

/***/ }),

/***/ 5091:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(4178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(2947);
// EXTERNAL MODULE: ./public/assets/Leaf.png
var Leaf = __webpack_require__(7806);
;// CONCATENATED MODULE: ./public/assets/fqa.png
/* harmony default export */ const fqa = ({"src":"/_next/static/media/fqa.1432c5e2.png","height":616,"width":606,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+Adjd6DgMCQkfoK2uM7/V11a96ev4HQ0LseOilHjV2uP/AeXn8pTc4uJrP2d1AE9BNdwfEhHmkrjBPp5zatlJOzrSAfb//yG3pauB3ePjE2BscprW1tYbaX18lX9dVt49SVKYAfbP2Sux+d6uGA0QywztCcM1jZWIhTYaECw+KZo0FC1nAQC4igCK/B22FQ0SB7GfuSqw6/EYiV9Ds/gD+OfXA/BnAQD//AUAanqeUCobE+nx6tkA/wHY2Pr7H+/d7jdojk5jAUe4iOLz3P8Kyujudg7x8VYHCQkGDREGtgj+A3QZNxcHAUa0j6H83QERDPERqeHx4XkDAgb/GxMajfH/6EsKLgoFGKJ/VKVx17AAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/FAQbg.png
/* harmony default export */ const FAQbg = ({"src":"/_next/static/media/FAQbg.d2e9808b.png","height":301,"width":617,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAATElEQVR42jWMwQ3AIAwDXaCQlq5WdoD9h+ASicfJF8WJNGaFprESaSC8kA+ZhXSkQYEPKsQSuhde/etmMHcSomDhLDN40S8u8Ezn6wbbZBa4L84YwAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});
// EXTERNAL MODULE: ./public/assets/aboutbg.png
var aboutbg = __webpack_require__(5632);
// EXTERNAL MODULE: ./public/assets/img1.png
var img1 = __webpack_require__(1152);
// EXTERNAL MODULE: ./public/assets/Ellipse.png
var Ellipse = __webpack_require__(6385);
// EXTERNAL MODULE: ./public/assets/Lefe2.png
var Lefe2 = __webpack_require__(9995);
// EXTERNAL MODULE: ./public/assets/Leaf2.png
var Leaf2 = __webpack_require__(5473);
// EXTERNAL MODULE: ./public/assets/lefe1.png
var lefe1 = __webpack_require__(5363);
;// CONCATENATED MODULE: ./app/Pages/Userside/faq/page.jsx












const FQA = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " mb-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: "  h-[400px] top-[83px]",
                        src: aboutbg/* default */.Z
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex justify-between top-48 absolute ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " ml-0  h-60 ",
                                src: Leaf/* default */.Z,
                                alt: ""
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " ml-[100px]",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: " absolute w-[400px]",
                                        src: FAQbg
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: " text-[#015464] mt-44 text-3xl font-extrabold top-[351px]  h-[16px]",
                                        children: "Frequently Asked Questions "
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: " text-[#015464] font-extrabold text-xl mt-16",
                                        children: "Welcome to Enool!L"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-[#015464] mt-10 text-sm font-medium left-[965px] w-[500px] h-[146px]",
                                        children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " ml-[50px] h-[250]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: " top-[130px] w-[350px]",
                                    src: fqa,
                                    alt: ""
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: " absolute left-[1100px] top-24 w-24 ",
                        src: lefe1/* default */.Z,
                        alt: ""
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " mt-[180px] ml-[250px]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " absolute left-7 mt-40",
                                src: Ellipse/* default */.Z,
                                alt: ""
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " absolute top-[450px] w-[400px] left-[-250px]",
                                src: img1/* default */.Z
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                className: " relative bg-[#015464] opacity-1 text-sm font-medium ml-[-50px] py-14 px-12 rounded-xl text-white ",
                                children: [
                                    "General ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                        className: " "
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: " relative bg-[#408080] opacity-1 text-sm font-medium py-11 px-7 pb-9 pt-14 ml-10 w-[150px] rounded-xl text-white ",
                                children: "SUBSCRIPTION  & ACCOUNT"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: " relative bg-[#7CC9B5] opacity-1 text-sm font-medium ml-10 py-14 px-12 rounded-xl text-white ",
                                children: "PAYMENT"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " ml-[300px] mt-28 ",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " relative w-[700px] overflow-hidden pb-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                className: " peer absolute top-0 inset-x-0 w-full h-12 opacity-0 z-10 cursor-pointer",
                                type: "checkbox"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " h-12 w-full flex items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: " text-lg font-semibold text-[#015464]",
                                    children: "01. Welcome to Enool!"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " absolute top-3 right-3 text-[#015464] peer-checked:rotate-45 transition-transform duration-500 rotate-0",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    fill: "none",
                                    viewBox: "0 0 24 24",
                                    "stroke-width": "1.5",
                                    stroke: "currentColor",
                                    className: "w-6 h-6",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        "stroke-linecap": "round",
                                        "stroke-linejoin": "round",
                                        d: "M12 4.5v15m7.5-7.5h-15"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " max-h-0 bg-white overflow-hidden transition-all duration-500 peer-checked:max-h-40",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: " text-[#14adad] p-4",
                                    children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit doloribus impedit totam nulla, dolorum numquam recusandae facere modi mollitia? Eveniet sunt quas voluptas iure facere nesciunt dolor corporis illum voluptate."
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " relative w-[700px] overflow-hidden pb-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                className: " peer absolute top-0 inset-x-0 w-full h-12 opacity-0 z-10 cursor-pointer",
                                type: "checkbox"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " h-12 w-full flex items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: " text-lg font-semibold text-[#015464]",
                                    children: "02. Welcome to Enool!"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " absolute top-3 right-3 text-[#015464] peer-checked:rotate-45 transition-transform duration-500 rotate-0",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    fill: "none",
                                    viewBox: "0 0 24 24",
                                    "stroke-width": "1.5",
                                    stroke: "currentColor",
                                    className: "w-6 h-6",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        "stroke-linecap": "round",
                                        "stroke-linejoin": "round",
                                        d: "M12 4.5v15m7.5-7.5h-15"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " max-h-0 bg-white overflow-hidden transition-all duration-500 peer-checked:max-h-40",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: " text-[#14adad] p-4",
                                    children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit doloribus impedit totam nulla, dolorum numquam recusandae facere modi mollitia? Eveniet sunt quas voluptas iure facere nesciunt dolor corporis illum voluptate."
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " relative w-[700px] overflow-hidden pb-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                className: " peer absolute top-0 inset-x-0 w-full h-12 opacity-0 z-10 cursor-pointer",
                                type: "checkbox"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " h-12 w-full flex items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: " text-lg font-semibold text-[#015464]",
                                    children: "03. Welcome to Enool!"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " absolute top-3 right-3 text-[#015464] peer-checked:rotate-45 transition-transform duration-500 rotate-0",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    fill: "none",
                                    viewBox: "0 0 24 24",
                                    "stroke-width": "1.5",
                                    stroke: "currentColor",
                                    className: "w-6 h-6",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        "stroke-linecap": "round",
                                        "stroke-linejoin": "round",
                                        d: "M12 4.5v15m7.5-7.5h-15"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " max-h-0 bg-white overflow-hidden transition-all duration-500 peer-checked:max-h-40",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: " text-[#14adad] p-4",
                                    children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit doloribus impedit totam nulla, dolorum numquam recusandae facere modi mollitia? Eveniet sunt quas voluptas iure facere nesciunt dolor corporis illum voluptate."
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " relative w-[700px] overflow-hidden pb-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                className: " peer absolute top-0 inset-x-0 w-full h-12 opacity-0 z-10 cursor-pointer",
                                type: "checkbox"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " h-12 w-full flex items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: " text-lg font-semibold text-[#015464]",
                                    children: "04. Welcome to Enool!"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " absolute top-3 right-3 text-[#015464] peer-checked:rotate-45 transition-transform duration-500 rotate-0",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    fill: "none",
                                    viewBox: "0 0 24 24",
                                    "stroke-width": "1.5",
                                    stroke: "currentColor",
                                    className: "w-6 h-6",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        "stroke-linecap": "round",
                                        "stroke-linejoin": "round",
                                        d: "M12 4.5v15m7.5-7.5h-15"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " max-h-0 bg-white overflow-hidden transition-all duration-500 peer-checked:max-h-40",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: " text-[#14adad] p-4",
                                    children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit doloribus impedit totam nulla, dolorum numquam recusandae facere modi mollitia? Eveniet sunt quas voluptas iure facere nesciunt dolor corporis illum voluptate."
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " relative w-[700px] overflow-hidden pb-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                className: " peer absolute top-0 inset-x-0 w-full h-12 opacity-0 z-10 cursor-pointer",
                                type: "checkbox"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " h-12 w-full flex items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: " text-lg font-semibold text-[#015464]",
                                    children: "05. Welcome to Enool!"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " absolute top-3 right-3 text-[#015464] peer-checked:rotate-45 transition-transform duration-500 rotate-0",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    fill: "none",
                                    viewBox: "0 0 24 24",
                                    "stroke-width": "1.5",
                                    stroke: "currentColor",
                                    className: "w-6 h-6",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        "stroke-linecap": "round",
                                        "stroke-linejoin": "round",
                                        d: "M12 4.5v15m7.5-7.5h-15"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " max-h-0 bg-white overflow-hidden transition-all duration-500 peer-checked:max-h-40",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: " text-[#14adad] p-4",
                                    children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit doloribus impedit totam nulla, dolorum numquam recusandae facere modi mollitia? Eveniet sunt quas voluptas iure facere nesciunt dolor corporis illum voluptate."
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " relative w-[700px] overflow-hidden pb-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                className: " peer absolute top-0 inset-x-0 w-full h-12 opacity-0 z-10 cursor-pointer",
                                type: "checkbox"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " h-12 w-full flex items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: " text-lg font-semibold text-[#015464]",
                                    children: "06. Welcome to Enool!"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " absolute top-3 right-3 text-[#015464] peer-checked:rotate-45 transition-transform duration-500 rotate-0",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    fill: "none",
                                    viewBox: "0 0 24 24",
                                    "stroke-width": "1.5",
                                    stroke: "currentColor",
                                    className: "w-6 h-6",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        "stroke-linecap": "round",
                                        "stroke-linejoin": "round",
                                        d: "M12 4.5v15m7.5-7.5h-15"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " max-h-0 bg-white overflow-hidden transition-all duration-500 peer-checked:max-h-40",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: " text-[#14adad] p-4",
                                    children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit doloribus impedit totam nulla, dolorum numquam recusandae facere modi mollitia? Eveniet sunt quas voluptas iure facere nesciunt dolor corporis illum voluptate."
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " relative w-[700px] overflow-hidden pb-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                className: " peer absolute top-0 inset-x-0 w-full h-12 opacity-0 z-10 cursor-pointer",
                                type: "checkbox"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " h-12 w-full flex items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: " text-lg font-semibold text-[#015464]",
                                    children: "07. Welcome to Enool!"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " absolute top-3 right-3 text-[#015464] peer-checked:rotate-45 transition-transform duration-500 rotate-0",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    fill: "none",
                                    viewBox: "0 0 24 24",
                                    "stroke-width": "1.5",
                                    stroke: "currentColor",
                                    className: "w-6 h-6",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        "stroke-linecap": "round",
                                        "stroke-linejoin": "round",
                                        d: "M12 4.5v15m7.5-7.5h-15"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " max-h-0 bg-white overflow-hidden transition-all duration-500 peer-checked:max-h-40",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: " text-[#14adad] p-4",
                                    children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit doloribus impedit totam nulla, dolorum numquam recusandae facere modi mollitia? Eveniet sunt quas voluptas iure facere nesciunt dolor corporis illum voluptate."
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " relative w-[700px] overflow-hidden",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                className: " peer absolute top-0 inset-x-0 w-full h-12 opacity-0 z-10 cursor-pointer",
                                type: "checkbox"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " h-12 w-full flex items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: " text-lg font-semibold text-[#015464]",
                                    children: "08. Welcome to Enool!"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " absolute top-3 right-3 text-[#015464] peer-checked:rotate-45 transition-transform duration-500 rotate-0",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    fill: "none",
                                    viewBox: "0 0 24 24",
                                    "stroke-width": "1.5",
                                    stroke: "currentColor",
                                    className: "w-6 h-6",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        "stroke-linecap": "round",
                                        "stroke-linejoin": "round",
                                        d: "M12 4.5v15m7.5-7.5h-15"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " max-h-0 bg-white overflow-hidden transition-all duration-500 peer-checked:max-h-40",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: " text-[#14adad] p-4",
                                    children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit doloribus impedit totam nulla, dolorum numquam recusandae facere modi mollitia? Eveniet sunt quas voluptas iure facere nesciunt dolor corporis illum voluptate."
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: " absolute top-[800px] left-[1520px] w-[120px]",
                        src: Leaf2/* default */.Z
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: " absolute top-[900px] left-[1150px] w-[120px]",
                        src: Lefe2/* default */.Z,
                        alt: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: " absolute top-[1010px] left-[1300px] w-[350px]",
                        src: img1/* default */.Z,
                        alt: ""
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const page = (FQA);


/***/ }),

/***/ 7234:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/FAQbg.d2e9808b.png","height":301,"width":617,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAATElEQVR42jWMwQ3AIAwDXaCQlq5WdoD9h+ASicfJF8WJNGaFprESaSC8kA+ZhXSkQYEPKsQSuhde/etmMHcSomDhLDN40S8u8Ezn6wbbZBa4L84YwAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 9925:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/fqa.1432c5e2.png","height":616,"width":606,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+Adjd6DgMCQkfoK2uM7/V11a96ev4HQ0LseOilHjV2uP/AeXn8pTc4uJrP2d1AE9BNdwfEhHmkrjBPp5zatlJOzrSAfb//yG3pauB3ePjE2BscprW1tYbaX18lX9dVt49SVKYAfbP2Sux+d6uGA0QywztCcM1jZWIhTYaECw+KZo0FC1nAQC4igCK/B22FQ0SB7GfuSqw6/EYiV9Ds/gD+OfXA/BnAQD//AUAanqeUCobE+nx6tkA/wHY2Pr7H+/d7jdojk5jAUe4iOLz3P8Kyujudg7x8VYHCQkGDREGtgj+A3QZNxcHAUa0j6H83QERDPERqeHx4XkDAgb/GxMajfH/6EsKLgoFGKJ/VKVx17AAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 5363:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/lefe1.7cd3c653.png","height":321,"width":164,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAfElEQVR42mNIOzBRzmdnCwcDEITu7mBkSN4/IS92b09Z8O52AQYQiNrbbZi4r29G5J4uPQYYSNjXZ5eyf6IfAwiUHJnFmnFgskzqgYnWmQcn2zLE7O1hSdrfXwI0UKjs6Gw2BhBIOzDJCSjIywADhYdnyBQdninCwMDAAAD7WCsf8H+m5wAAAABJRU5ErkJggg==","blurWidth":4,"blurHeight":8});

/***/ }),

/***/ 5915:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/lefe1.7cd3c653.png","height":321,"width":164,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAfElEQVR42mNIOzBRzmdnCwcDEITu7mBkSN4/IS92b09Z8O52AQYQiNrbbZi4r29G5J4uPQYYSNjXZ5eyf6IfAwiUHJnFmnFgskzqgYnWmQcn2zLE7O1hSdrfXwI0UKjs6Gw2BhBIOzDJCSjIywADhYdnyBQdninCwMDAAAD7WCsf8H+m5wAAAABJRU5ErkJggg==","blurWidth":4,"blurHeight":8});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [152,131,210,349,61,215], () => (__webpack_exec__(7079)));
module.exports = __webpack_exports__;

})();