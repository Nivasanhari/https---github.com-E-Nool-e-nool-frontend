(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 9477:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4578)), "C:\\Project\\e-nool-frontend\\app\\page.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9376)), "C:\\Project\\e-nool-frontend\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Project\\e-nool-frontend\\app\\page.js"];

    

    const originalPathname = "/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/page","pathname":"/","bundlePath":"app/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 670:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5814));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5671));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9848));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4079));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 514));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1066));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6465));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6149));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4120));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8425));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5579));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 362));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6963));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5972));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7295));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7202));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5028));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7834));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5029));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8763));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8590));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2730));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2473));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3814));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6580));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4546));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7541));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8197));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3327))

/***/ }),

/***/ 6149:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ BrowseCategories)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/assets/LandingPage/browse-categories1.png
/* harmony default export */ const browse_categories1 = ({"src":"/_next/static/media/browse-categories1.88c9b3bf.png","height":252,"width":232,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA4ElEQVR42mPo2bmKddmjg6wMDMmCbfs2WE87vsl/zuGNhgxwEBXP6ecS1ZgZl3N++uV9QXUnN8Y1rF9gyLD3zl3W/DX9DlOW7Zw3e/rqLUvOLXI/tW7dsp4l8zwZph3dKTPh8KKwaevuXp227dXzRTP3HN/d2HtMZ9PCYIYpRzYmTT+1ubRn0bl3MRlz/jMoFv+vnNi2f96c8psMkw9vCJx1ZkdlcFHrOjOVyLNOZuHvJ66ePvnYlp5IBnSQ6+rSBqREwZwpRzcyTz61g2mGfw0LiL+votRyf0uNCAMDAwMAAftjXRy9nyoAAAAASUVORK5CYII=","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/BrowseCategories.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



function BrowseCategories() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "w-full",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " mx-auto flex justify-between items-center sm:px-16 px-6 py-4",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "  md-px-24 relative  container pt-24 mx-auto",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-wrap w-full mb-10",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "lg:w-1/2 w-full mb-6 lg:mb-0 ",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                            className: "sm:text-3xl text-2xlads font-bold title-font mb-2 text-[#015464]",
                                            children: "Browse Book Categories"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "h-1 w-48 bg-[#0FBF61] opacity-20 rounded"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: " font-sm  text-[#4B8787]  mt-2 ",
                                            children: "Buzzworthy,bestselling and bingeable.Read the books everyone is talking about right now"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "lg:w-1/2 w-full mb-6 lg:mb-0 flex lg:justify-end ",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: " text-white bg-[#015464] border-0 py-2 px-6 focus:outline-none w-28 h-10 rounded-[21px] text-sm ",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                            className: "items-center",
                                            children: "View all"
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "p-6 rounded-lg",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                className: "rounded w-auto object-cover object-center mb-6",
                                                src: browse_categories1,
                                                alt: "content"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "text-lg text-[#015464] font-bold mb-1",
                                                children: "Young Adult"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "p-6 rounded-lg",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                className: "rounded w-auto object-cover object-center mb-6",
                                                src: browse_categories1,
                                                alt: "content"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "text-lg text-[#015464] font-bold mb-1",
                                                children: "Young Adult"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "p-6 rounded-lg",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                className: "rounded w-auto object-cover object-center mb-6",
                                                src: browse_categories1,
                                                alt: "content"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "text-lg text-[#015464] font-bold mb-1",
                                                children: "Young Adult"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "p-6 rounded-lg",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                className: "rounded w-auto object-cover object-center mb-6",
                                                src: browse_categories1,
                                                alt: "content"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "text-lg text-[#015464] font-bold mb-1",
                                                children: "Young Adult"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "p-6 rounded-lg",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                className: "rounded w-auto object-cover object-center mb-6",
                                                src: browse_categories1,
                                                alt: "content"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "text-lg text-[#015464] font-bold mb-1",
                                                children: "Young Adult"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mx-auto flex justify-between items-center sm:px-16 px-6 py-4",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col items-center w-full mb-20",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "sm:text-3xl text-2xl font-bold title-font mb-4 text-[#015464]",
                            children: "100 + Books Genre for Readers"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-xs text-[#565656] tracking-widest font-medium title-font pb-3",
                            children: "Your Next#Enool Read Is Here"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "h-1 w-20 bg-[#0FBF61] opacity-20 rounded justify-center"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "flex mx-auto mt-3 text-white bg-[#7CC9B5] border-0 py-2 px-8 focus:outline-none hover:bg-[#578f80] rounded-[23px] text-sm",
                            children: "Explore Now"
                        })
                    ]
                })
            })
        ]
    });
}
{}

/***/ }),

/***/ 5028:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2451);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_pageflip__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8320);
/* harmony import */ var react_pageflip__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_pageflip__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _public_assets_LandingPage_Leaf1_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1066);
/* harmony import */ var _public_assets_LandingPage_Leaf2_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3742);
/* harmony import */ var _app_components_FlipbookPlayer_page_jsx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9392);
/* __next_internal_client_entry_do_not_use__ default auto */ 






const Flipbook = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: " w-full  ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "read_book_bg"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_app_components_FlipbookPlayer_page_jsx__WEBPACK_IMPORTED_MODULE_6__["default"], {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Flipbook);


/***/ }),

/***/ 5579:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Hero)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./public/assets/LandingPage/Leaf1.png
var Leaf1 = __webpack_require__(1066);
// EXTERNAL MODULE: ./public/assets/LandingPage/Leaf2.png
var Leaf2 = __webpack_require__(3742);
;// CONCATENATED MODULE: ./public/assets/LandingPage/hero.png
/* harmony default export */ const hero = ({"src":"/_next/static/media/hero.2e1a5e85.png","height":1096,"width":1284,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA8klEQVR4nAHnABj/AfTt5YP/+/kP/fz6/wYGBvj+FSGKcL6pJhgJCyn9/v20Ae3Vu/D/+/cPAgMCAPv6/AC21OJ92CchEQX+/xX+AAAcAerNuOEA//se/fz2+vcAAQbpp6nBnFdhzxUBABkD//5DAenMtuQGCgAbvq+6//rw6gDB49f8PycZ2upAXazkBwxOAfPl1uHv3M4et5Sm/h/9tgAlMxECAPfvAOUqd0mjK0oKAfTl1u7s1sgRy4diABw9RgAPBuHe//nZ6JG3AMaaywCYAfTi0KLp39cj2ri8KCdPUsXcCBxwRST43hwgS7wREwqQ7YZ5fqc5yQcAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/icons/play-button.png
/* harmony default export */ const play_button = ({"src":"/_next/static/media/play-button.29f1bb98.png","height":257,"width":257,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA3klEQVR42mOAAe7Q5BTesJT9DCFJ+9lDklIYkAFvaHIXQ3DSf4agxP/SkWn/gYr+c4YkdYEllUKTjBmCE//LR6X/5wtP/cNg7PWHMywZrEg+JNGYQTo8NYMhMP6/Tnz2n1dv3v5ft2PPfwb3iD/84Sn/BUOTMxiUwlM8GQIT/usl5Pw6ePL0v6bJM/8x+Mb+4gpL+S8VmuTJAAJsIUkHWUHGGnv9Z7AJ+M8BlGQNSTrAAAP+ofGCfCFJixWi0l9IRqS+4AWy/cPiBcGS5RExzDCFXuEJAp6h8QJAJlwOABSSUUAcU5UTAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/pause-button.png
/* harmony default export */ const pause_button = ({"src":"/_next/static/media/pause-button.a2496bf3.png","height":257,"width":257,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAgVBMVEUAVmYBVGQAVGQAU2MAUmIATl0AU2MAUmIAU2IAU2IAUmIAU2MAU2MAU2MAU2MAU2MBU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAU2MAVGQAU2QAU2PiY255AAAAKHRSTlMAAAAAAAACBwgKDCo3OkhZZWlsbW6DhoeRlZydsL7Dxc/W2+Dh4+TqNgGKYwAAAEVJREFUeNoFQIURgDAQC1/c3Ypryf4DcnCsfFlry4Y05MdeEPEd9cUYmTnKajMFEp5ttzOFTIY0M6C84X50qOAq8QNR7g/VPgWDjxmPwAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/swiper/swiper-react.mjs + 3 modules
var swiper_react = __webpack_require__(2797);
// EXTERNAL MODULE: ./node_modules/swiper/modules/index.mjs + 26 modules
var modules = __webpack_require__(1987);
// EXTERNAL MODULE: ./node_modules/swiper/swiper.css
var swiper = __webpack_require__(3754);
// EXTERNAL MODULE: ./node_modules/swiper/modules/pagination.css
var pagination = __webpack_require__(3141);
// EXTERNAL MODULE: ./node_modules/swiper/modules/navigation.css
var navigation = __webpack_require__(2119);
;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/Hero.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 









// Import Swiper styles



function Hero() {
    const slidesData = [
        {
            title: "The Easiest Way to Find Any Book.",
            subtitle: "Unlimited reading for the world: millions of books in the browser, accessible to billions of people.",
            buttonText: "Get Started",
            imageSrc: hero
        }
    ];
    const swiperRef = (0,react_.useRef)(null);
    const [isAutoplay, setIsAutoplay] = (0,react_.useState)(true);
    const toggleAutoplay = ()=>{
        setIsAutoplay(!isAutoplay);
        if (isAutoplay) {
            swiperRef.current.swiper.autoplay.start();
        } else {
            swiperRef.current.swiper.autoplay.stop();
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "w-full ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: " absolute z-0 top-20 w-16 ",
                src: Leaf1["default"],
                alt: ""
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: " hidden lg:block absolute z-0 bottom-36 left-[30%] w-36 ",
                src: Leaf2/* default */.Z,
                alt: ""
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "z-10  mx-auto  justify-between items-center sm:px-16  py-4 ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "hidden md:block  ",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(swiper_react/* Swiper */.tq, {
                            ref: swiperRef,
                            spaceBetween: 3,
                            centeredSlides: true,
                            autoplay: {
                                delay: 2500,
                                disableOnInteraction: false
                            },
                            loop: true,
                            pagination: {
                                el: ".swiper-pagination-right",
                                clickable: true,
                                renderBullet: (index, className)=>{
                                    return `<span className="${className}" style="background-color: #015464;"></span>`;
                                }
                            },
                            modules: [
                                modules/* Autoplay */.pt,
                                modules/* Pagination */.tl,
                                modules/* Navigation */.W_
                            ],
                            className: "mySwiper",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "md:container md:mx-auto flex  pt-24 md:flex-row flex-col items-center",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "  lg:w-full md:w-1/2 w-5/6 lg:flex-grow  lg:pr-24 md:pr-16 flex flex-col md:items-start   md:text-left sm:text-center ",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                                        className: "text-4xl md:mt-36  text-[#015464]",
                                                        children: [
                                                            "The ",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: " text-[#105464] font-bold",
                                                                children: "Easiest Way"
                                                            }),
                                                            " to ",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                            "Find Any",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: " font-bold text-[#015464]",
                                                                children: "Book."
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: " text-[#408080] mt-8 font-medium",
                                                        children: "Unlimited reading for the world: millions of books in the browser, accessible to billions of people."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex justify-center  pt-10",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            className: "inline-flex text-white bg-[#7CC9B5] border-0 py-2 px-6 focus:outline-none hover:bg-[#447466] rounded-[23px] text-lg",
                                                            children: "Get Started"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex justify-center mt-28"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "lg:max-w-lg lg:w-full md:w-1/2 w-5/6 md:items-center  ",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: "object-cover object-center rounded",
                                                    alt: "hero",
                                                    src: hero
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "md:container md:mx-auto flex  pt-24 md:flex-row flex-col items-center",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "  lg:w-full md:w-1/2 w-5/6 lg:flex-grow  lg:pr-24 md:pr-16 flex flex-col md:items-start md:  mb-16 md:mb-0  md:text-left sm:text-center ",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                                        className: "text-4xl md:mt-36  text-[#015464]",
                                                        children: [
                                                            "The ",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: " text-[#105464] font-bold",
                                                                children: "Easiest Way"
                                                            }),
                                                            " to ",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                            "Find Any",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: " font-bold text-[#015464]",
                                                                children: "Book."
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: " text-[#408080] mt-8 font-medium",
                                                        children: "Unlimited reading for the world: millions of books in the browser, accessible to billions of people."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex justify-center  pt-10",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            className: "inline-flex text-white bg-[#7CC9B5] border-0 py-2 px-6 focus:outline-none hover:bg-[#447466] rounded-[23px] text-lg",
                                                            children: "Get Started"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex justify-center mt-28"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "lg:max-w-lg lg:w-full md:w-1/2 w-5/6 md:items-center  ",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: "object-cover object-center rounded",
                                                    alt: "hero",
                                                    src: hero
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "hidden md:container md:mx-auto md:flex   md:flex-row flex-col items-center",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "  lg:w-full md:w-1/2 w-5/6 lg:flex-grow  lg:pr-24 md:pr-24 flex flex-row md:items-start md:  mb-16 md:mb-0  md:text-left sm:text-center ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    type: "button",
                                    onClick: toggleAutoplay,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: "w-10 h-10 mr-2 object-cover  rounded",
                                        alt: "hero",
                                        src: isAutoplay ? play_button : pause_button
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "swiper-pagination-right mt-2 space-x-1"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "md:hidden md:container md:mx-auto   flex  lg:px-5 pt-24 md:flex-row flex-col items-center ",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " lg:max-w-lg lg:w-full md:w-1/2 w-5/6 lg:flex-grow  lg:pr-24 md:pr-16 flex flex-col md:items-start  mb-16 md:mb-0  md:text-left text-center ",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                        className: "text-4xl md:mt-36  text-[#015464]",
                                        children: [
                                            "The ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: " text-[#105464] font-bold",
                                                children: "Easiest Way"
                                            }),
                                            " to ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                            "Find Any",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: " font-bold text-[#015464]",
                                                children: "Book."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " text-[#408080] mt-8 font-medium",
                                        children: "Unlimited reading for the world: millions of books in the browser, accessible to billions of people."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex justify-center  pt-10",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "inline-flex text-white bg-[#7CC9B5] border-0 py-2 px-6 focus:outline-none hover:bg-[#447466] rounded-[23px] text-lg",
                                            children: "Get Started"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex justify-center mt-10 sm:h-80",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            className: " object-center rounded w-[60%]",
                                            alt: "hero",
                                            src: hero
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "lg:max-w-lg lg:w-full md:w-1/2 w-[44%] md:items-center  "
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 8425:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Testimonials)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./public/assets/LandingPage/Leaf2.png
var Leaf2 = __webpack_require__(3742);
;// CONCATENATED MODULE: ./public/assets/LandingPage/testimonial-object.png
/* harmony default export */ const testimonial_object = ({"src":"/_next/static/media/testimonial-object.c1d2e138.png","height":40,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAgklEQVR42h2LMQqDQBRE9wLpUqdJGVKHdOnSBVIklQfwFBZqLQg2/g9qpyCCx9k9gP8cvnXhMTvzZ5yGzcEHCrgIHu4aLId3PP4IZvRJ4OCKH/Gp48VAxW+CdnCTYAk6UZCjhGnEW6/eVpZ/+DJYyAf+bSw8CCpMyeKMP0FGVmuw1w7pOmsKd2xkaQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/Testimonials.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




function Testimonials() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "mt-10  text-gray-600 relative",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: Leaf2/* default */.Z,
                alt: "",
                className: "absolute mt-96"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full md-px-24 relative  container  py-24 mx-auto px-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-wrap w-full mb-10 lg:flex-row flex-col",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "lg:w-1/2 w-full mb-6 lg:mb-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: "text-3xl font-bold title-font pb-4 text-[#015464] lg:w-[60%]",
                                        children: "What Readers Says"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "h-1 w-48 bg-[#0FBF61] opacity-20 rounded"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "lg:w-1/2 w-full mb-6 lg:mb-0 lg:flex md:justify-end items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: " text-white bg-[#015464] border-0 py-2 px-6 focus:outline-none w-28 h-10 rounded-[21px] text-sm ",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: "items-center",
                                        children: "View all"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "container m-auto  text-gray-600 ",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "grid gap-7 sm:grid-rows-1 md:grid-rows-2  lg:grid-cols-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "row-span-2 p-6 border border-gray-100 rounded-xl bg-[#FEF5F5] text-center sm:p-8",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "h-full flex flex-col justify-center space-y-4",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                className: "w-20 h-20 mx-auto rounded-full",
                                                src: "https://tailus.io/sources/blocks/grid-cards/preview/images/avatars/second_user.webp",
                                                alt: "user avatar",
                                                height: "220",
                                                width: "220",
                                                loading: "lazy"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-[#015464] md:text-xl",
                                                children: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat repellat perspiciatis excepturi est. Non ipsum iusto aliquam consequatur repellat provident, "'
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "relative text-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: testimonial_object,
                                                        alt: "card-object",
                                                        className: "mx-auto"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "absolute inset-0 flex flex-col items-center justify-center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                            className: "text-lg font-semibold leading-none text-[#015464]",
                                                            children: "Jane Doe / New York"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "row-span-2 p-6 border border-gray-100 rounded-xl bg-[#F4FBF2] text-center sm:p-8",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "h-full flex flex-col justify-center space-y-4",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                className: "w-20 h-20 mx-auto rounded-full",
                                                src: "https://tailus.io/sources/blocks/grid-cards/preview/images/avatars/second_user.webp",
                                                alt: "user avatar",
                                                height: "220",
                                                width: "220",
                                                loading: "lazy"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-[#015464] md:text-xl",
                                                children: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat repellat perspiciatis excepturi est. Non ipsum iusto aliquam consequatur repellat provident, "'
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "relative text-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: testimonial_object,
                                                        alt: "card-object",
                                                        className: "mx-auto"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "absolute inset-0 flex flex-col items-center justify-center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                            className: "text-lg font-semibold leading-none text-[#015464]",
                                                            children: "Jane Doe / New York"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "row-span-2 p-6 border border-gray-100 rounded-xl bg-[#FEF5F5] text-center sm:p-8",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "h-full flex flex-col justify-center space-y-4",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                className: "w-20 h-20 mx-auto rounded-full",
                                                src: "https://tailus.io/sources/blocks/grid-cards/preview/images/avatars/second_user.webp",
                                                alt: "user avatar",
                                                height: "220",
                                                width: "220",
                                                loading: "lazy"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-[#015464] md:text-xl",
                                                children: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat repellat perspiciatis excepturi est. Non ipsum iusto aliquam consequatur repellat provident, "'
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "relative text-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: testimonial_object,
                                                        alt: "card-object",
                                                        className: "mx-auto"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "absolute inset-0 flex flex-col items-center justify-center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                            className: "text-lg font-semibold leading-none text-[#015464]",
                                                            children: "Jane Doe / New York"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: " lg:hidden lg:w-1/2 w-full my-6 lg:mb-0 flex justify-center ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: " text-white bg-[#015464] border-0 py-2 px-6 focus:outline-none w-28 h-10 rounded-[21px] text-sm ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "items-center",
                                children: "View all"
                            })
                        })
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 4120:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ TrendingReads)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/swiper/swiper-react.mjs + 3 modules
var swiper_react = __webpack_require__(2797);
// EXTERNAL MODULE: ./node_modules/swiper/modules/index.mjs + 26 modules
var modules = __webpack_require__(1987);
// EXTERNAL MODULE: ./node_modules/swiper/swiper.css
var swiper = __webpack_require__(3754);
// EXTERNAL MODULE: ./node_modules/swiper/modules/pagination.css
var pagination = __webpack_require__(3141);
// EXTERNAL MODULE: ./node_modules/swiper/modules/navigation.css
var navigation = __webpack_require__(2119);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./public/assets/LandingPage/Trending curve.png
var Trending_curve = __webpack_require__(7834);
// EXTERNAL MODULE: ./public/assets/LandingPage/TrendingReads1.png
var TrendingReads1 = __webpack_require__(4546);
// EXTERNAL MODULE: ./public/icons/eye.png
var eye = __webpack_require__(7541);
// EXTERNAL MODULE: ./public/icons/heart.png
var heart = __webpack_require__(8197);
// EXTERNAL MODULE: ./public/icons/more-options-dotted.png
var more_options_dotted = __webpack_require__(3327);
;// CONCATENATED MODULE: ./app/components/CarouselCards/CarouselCards.jsx









function CarouselCardItems() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: " rounded w-56 object-cover object-center mb-4",
                src: TrendingReads1["default"],
                alt: "content"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "text-[16px] text-[#1A6270] font-bold   mb-2",
                children: "King of Battle and Blood"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-wrap mb-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        className: "w-4 h-4 text-yellow-300",
                        "aria-hidden": "true",
                        fill: "currentColor",
                        viewBox: "0 0 22 20",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        className: "w-4 h-4 text-yellow-300",
                        "aria-hidden": "true",
                        fill: "currentColor",
                        viewBox: "0 0 22 20",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        className: "w-4 h-4 text-yellow-300",
                        "aria-hidden": "true",
                        fill: "currentColor",
                        viewBox: "0 0 22 20",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        className: "w-4 h-4 text-yellow-300",
                        "aria-hidden": "true",
                        fill: "currentColor",
                        viewBox: "0 0 22 20",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        className: "w-4 h-4 text-gray-300 dark:text-gray-500",
                        "aria-hidden": "true",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "currentColor",
                        viewBox: "0 0 22 20",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "tracking-widest text-[#280c0c] text-xs  ",
                        children: "(27)"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "text-[12px] tracking-widest text-[#1A6270] text-xs  mb-2  ",
                children: "by Scarlett St.Clair"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-wrap space-x-4 pt-2 mb-1",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: eye["default"],
                        className: "w-8",
                        alt: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: heart["default"],
                        className: "w-8",
                        alt: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: more_options_dotted["default"],
                        className: "w-8",
                        alt: ""
                    })
                ]
            })
        ]
    });
}
const CarouselCards = ()=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: "grid grid-cols-2   md:grid-cols-3 lg:grid-cols-6 gap-4 lg:gap-3",
        children: [
            /*#__PURE__*/ _jsx(CarouselCardItems, {}),
            /*#__PURE__*/ _jsx(CarouselCardItems, {}),
            /*#__PURE__*/ _jsx(CarouselCardItems, {}),
            /*#__PURE__*/ _jsx(CarouselCardItems, {}),
            /*#__PURE__*/ _jsx(CarouselCardItems, {}),
            /*#__PURE__*/ _jsx(CarouselCardItems, {}),
            /*#__PURE__*/ _jsx(CarouselCardItems, {}),
            /*#__PURE__*/ _jsx(CarouselCardItems, {})
        ]
    });
};

;// CONCATENATED MODULE: ./public/icons/left-arrow.png
/* harmony default export */ const left_arrow = ({"src":"/_next/static/media/left-arrow.4cc127dc.png","height":54,"width":54,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAhFBMVEUm3r8m3r4m3b4m3r8m3r4m3b4m3b4m3r4m3b4m3r8m3r4m3b8m3r4m3r4m3b4m3r4m3b4o3r8n3r8n3b4n3b4m3b4l3b4k3b4h3b4g3b4n3b6X6daU6dV75c535M1H38NE38It3r8s3r8q3r8p3r8o3r8n3r8c3b4a3b4H3b0A3b0A3Lx9/ZYhAAAAG3RSTlMAAAAoKCgpKiq/v7/AwsLs7Pj4+Pn5+fn5+foXef8oAAAATElEQVR42hXGRxKAIAwAwCCKFQR7L2hi4f//c9zTAkSqMDJkwDWdN2oOGbXP2mMM1e7G2dkaBuum5U9Czbt1mIKf03GhDsATsjRKsA/PogXEbvFGkAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/right-arrow.png
/* harmony default export */ const right_arrow = ({"src":"/_next/static/media/right-arrow.75c28f58.png","height":54,"width":54,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAUVBMVEXS0tHS0tDS0tHS0tDT09DS0tDS0tDS0tHS0tDS0tHS0tDS0tDT09HS0tDS0tHS0tDS0tDi4uHi4uDd3dvc3NvV1dPT09HS0tDS0s/R0c/R0c5K/1deAAAAEXRSTlMAACgoKSkqv7/Awuz4+Pn5+h47z9cAAABCSURBVHjaJcvbGkAgFEThqUgK4zjs3v9B8XW91g/EPM05OviiWyoeo3g91ACqHlsVscrO3bQgfcmohNDmAHQ/790LhJ8DrUlUhI0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/TrendingReads.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



// Import Swiper styles



// import required modules










function TrendingReads() {
    const bookData = {
        imageSrc: TrendingReads1["default"],
        title: "King of Battle and Blood",
        rating: 4,
        author: "Scarlett St.Clair"
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: " w-full",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: " mx-auto flex justify-between items-center sm:px-16 px-6 py-4",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "  md-px-24 relative  container pt-24 mx-auto",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-wrap w-full mb-10",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "lg:w-1/2 w-full mb-6 lg:mb-0 ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: " text-3xl font-bold title-font mb-2 text-[#015464]",
                                        children: "Trending Reads"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "h-1 w-48 bg-[#0FBF61] opacity-20 rounded"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: " font-sm  text-[#4B8787]  mt-2 ",
                                        children: "Buzzworthy,bestselling and bingeable.Read the books everyone is talking about right now"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "lg:w-1/2 w-full mb-6 lg:mb-0 flex lg:justify-end ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: " text-white bg-[#015464] border-0 py-2 px-6 focus:outline-none w-28 h-10 rounded-[21px] text-sm ",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: "items-center",
                                        children: "View all"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(swiper_react/* Swiper */.tq, {
                        slidesPerView: 6,
                        spaceBetween: 1,
                        freeMode: true,
                        navigation: {
                            nextEl: ".swiper-button-next",
                            prevEl: ".swiper-button-prev"
                        },
                        modules: [
                            modules/* FreeMode */.Rv,
                            modules/* Pagination */.tl,
                            modules/* Navigation */.W_
                        ],
                        className: "mySwiper",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "justify-center mx-auto",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: "swiper-button-prev w-96 ",
                                        src: left_arrow
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: "swiper-button-next",
                                        src: right_arrow
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CarouselCardItems, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CarouselCardItems, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CarouselCardItems, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CarouselCardItems, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CarouselCardItems, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CarouselCardItems, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CarouselCardItems, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CarouselCardItems, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CarouselCardItems, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CarouselCardItems, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CarouselCardItems, {})
                            })
                        ]
                    })
                ]
            })
        })
    });
}


/***/ }),

/***/ 6580:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 


const CategoriesButton = ()=>{
    const dropdown = "/icons/dropdown.svg";
    const menuItems = [
        {
            label: "Online Stores",
            href: "#"
        },
        {
            label: "Segmentation",
            href: "#"
        },
        {
            label: "Marketing CRM",
            href: "#"
        },
        {
            label: "Online Stores",
            href: "#"
        }
    ];
    const additionalLinks = [
        {
            label: "Our Blog",
            href: "#"
        },
        {
            label: "Terms & Conditions",
            href: "#"
        },
        {
            label: "License",
            href: "#"
        },
        {
            label: "Resources",
            href: "#"
        }
    ];
    const [isDropdownOpen, setDropdownOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const handleDropdownToggle = ()=>{
        setDropdownOpen(!isDropdownOpen);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                type: "button",
                onClick: handleDropdownToggle,
                className: "flex items-center justify-between w-80 px-4 py-2 bg-[#7CC9B5] text-white rounded-3xl hover:bg-[#7CC9B5]/90 focus:outline-none space-x-2 flex-row",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "pl-5",
                        children: "Browse By Subject"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: dropdown,
                        alt: "Dropdown",
                        className: "w-3 h-3"
                    })
                ]
            }),
            isDropdownOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "absolute top-12 left-0 w-64 bg-white border border-gray-300 rounded-lg shadow-lg",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "grid max-w-screen-xl px-4 py-5 mx-auto text-sm text-gray-500 dark:text-gray-400 md:grid-cols-3 md:px-6",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            className: "hidden mb-4 space-y-4 md:mb-0 md:block",
                            "aria-labelledby": "mega-menu-full-image-button",
                            children: menuItems.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: item.href,
                                        className: "hover:underline hover:text-blue-600 dark:hover:text-blue-500",
                                        children: item.label
                                    })
                                }, index))
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            className: "mb-4 space-y-4 md:mb-0",
                            children: additionalLinks.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: item.href,
                                        className: "hover:underline hover:text-blue-600 dark:hover:text-blue-500",
                                        children: item.label
                                    })
                                }, index))
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                            href: "#",
                            className: "p-8 text-left bg-local bg-gray-500 bg-center bg-no-repeat bg-cover rounded-lg bg-blend-multiply hover:bg-blend-soft-light dark:hover:bg-blend-darken",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "max-w-xl mb-5 font-extrabold leading-tight tracking-tight text-white",
                                    children: "Preview the new Flowbite dashboard navigation."
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    type: "button",
                                    className: "inline-flex items-center px-2.5 py-1.5 text-xs font-medium text-center text-white border border-white rounded-lg hover:bg-white hover:text-gray-900 focus:ring-4 focus:outline-none focus:ring-gray-700",
                                    children: [
                                        "Get started",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            className: "w-3 h-3 ml-2",
                                            "aria-hidden": "true",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            fill: "none",
                                            viewBox: "0 0 14 10",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                stroke: "currentColor",
                                                "stroke-linecap": "round",
                                                "stroke-linejoin": "round",
                                                "stroke-width": "2",
                                                d: "M1 5h12m0 0L9 1m4 4L9 9"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoriesButton);


/***/ }),

/***/ 4578:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1363);
;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/BrowseCategories.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Project\e-nool-frontend\app\Pages\Userside\Landing Page\BrowseCategories.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const BrowseCategories = (__default__);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(4178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(2947);
;// CONCATENATED MODULE: ./public/assets/LandingPage/about object.png
/* harmony default export */ const about_object = ({"src":"/_next/static/media/about object.8f71b8f0.png","height":604,"width":505,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAMAAAAC2hU0AAAAUVBMVEUl6r8g6MIo38Em374n3r8n3r4m3r8m3r4n3b8n3b4m3b4o278AAAAn3r8n3r4m3r8m3r4n3b8n3b4m3b4n3r8n3r4m3r8m3r4n3b8n3b4m3b9/obNWAAAAG3RSTlMAAAAAAAAAAAAAAAAAAQEBAQEBAQICAgICAgJi4TjxAAAAPElEQVR42gVAARZAIAz9WC2jDGuT+x+0h3xZ88wQVQ5h5OZUO6M/y1E0YImSyItQrHupKN923mQg8zHin1fhAubBzyqMAAAAAElFTkSuQmCC","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/LandingPage/about1.png
/* harmony default export */ const about1 = ({"src":"/_next/static/media/about1.a8d01b83.png","height":591,"width":583,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA2klEQVR42mN4fecxKwMUTM8pLwFSUD4UvD5zNQVM1wn67esofPLg/r25bx7faQQKyRbWx4oz3Fq6ku3/v/9sb1utDOt6O9/cvf/k//2HL/6f3rz24ZTO8tkMUMCxo6XE6cK1u9cfPfvw//6Td78+La/9/2laRjcDCBzee8Ds4tye7y9efPj/9NWXny9fvP/x6OyZ/9tWbZjBAALzFq+RretYdO3i9Xtfjp659P/9x9//d5648mJqTVMoAxQwN/Su9jh04kLc9GUrJr7/8DPl6ZM3fv///xdgIAQAtkt3zfx7c+EAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/LandingPage/Leaf1.png
/* harmony default export */ const Leaf1 = ({"src":"/_next/static/media/Leaf1.0c89d817.png","height":348,"width":93,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAAICAYAAADTLS5CAAAAT0lEQVR4nGN0aC7g+xZl+p3R8vh0KwZmJm5Gi3NztBj//nNntDg/R5zh3/9wRouzs6UZ/jPYghhyQIYUo+WpmUL/mRilGS1frmf48/AlHwC1wBsCvAxfDgAAAABJRU5ErkJggg==","blurWidth":2,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/LandingPage/about2.png
/* harmony default export */ const about2 = ({"src":"/_next/static/media/about2.1a47e32a.png","height":132,"width":173,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAjklEQVR42mN4e+3uwjcXby1+e/O+87vbD8UZgODd3UeMDDDw9tYD4zcXbv5/dezSf6DCUAYgeH36KjMDMgDqjni570z+bYYGdgZ08ObybSYGIHi6Yi/Hq5NX2BiA4MWOE5JAjDDl/cOnTC/2nmF/vv24KFBCCoh1X2w/zsiADTzfcYIVqEAYiMWe7zghAAAI3krn4BvhyAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/About.jsx







// import LeafBg from 'public/assets/LandingPage/Leaf-Bg.png'
const About = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "relativew-full",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "z-10  mx-auto  justify-between items-center sm:px-16  py-4 ",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "hidden md:block  ",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "md:container md:mx-auto flex  pt-24 md:flex-row flex-col items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "lg:max-w-lg lg:w-full md:w-1/2 w-5/6 md:items-center  ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " left-56 top-[130px] w-[90%]",
                                src: about1,
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "  lg:w-full md:w-1/2 w-5/6 lg:flex-grow  lg:pr-24 md:pr-16 flex flex-col md:items-start   md:text-left sm:text-center ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: " text-[#015464] text-lg  top-[251px] left-[965px] w-[143px] h-[16px]",
                                    children: "WHO WE ARE"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: " text-[#015464] font-extrabold text-4xl mt-8",
                                    children: "About ENOOL"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: " text-[#015464] mt-10 text-sm font-medium left-[965px] w-full  ",
                                    children: "At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: " bg-[#14adad] opacity-1 mt-8 p-2 px-5 rounded-3xl text-white ",
                                    children: "Get Started"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex justify-center mt-28"
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const Landing_Page_About = (About);

;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/Hero.jsx

const Hero_proxy = (0,module_proxy.createProxy)(String.raw`C:\Project\e-nool-frontend\app\Pages\Userside\Landing Page\Hero.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Hero_esModule, $$typeof: Hero_$$typeof } = Hero_proxy;
const Hero_default_ = Hero_proxy.default;


/* harmony default export */ const Hero = (Hero_default_);
;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/TrendingReads.jsx

const TrendingReads_proxy = (0,module_proxy.createProxy)(String.raw`C:\Project\e-nool-frontend\app\Pages\Userside\Landing Page\TrendingReads.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: TrendingReads_esModule, $$typeof: TrendingReads_$$typeof } = TrendingReads_proxy;
const TrendingReads_default_ = TrendingReads_proxy.default;


/* harmony default export */ const TrendingReads = (TrendingReads_default_);
;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/Testimonials.jsx

const Testimonials_proxy = (0,module_proxy.createProxy)(String.raw`C:\Project\e-nool-frontend\app\Pages\Userside\Landing Page\Testimonials.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Testimonials_esModule, $$typeof: Testimonials_$$typeof } = Testimonials_proxy;
const Testimonials_default_ = Testimonials_proxy.default;


/* harmony default export */ const Testimonials = (Testimonials_default_);
;// CONCATENATED MODULE: ./public/assets/LandingPage/gettingstarted.png
/* harmony default export */ const gettingstarted = ({"src":"/_next/static/media/gettingstarted.815a3250.png","height":622,"width":654,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/UlEQVR42mP49u3bnx8/fmxkAAKDSx9YGYDg29cvuh8/fvz/5cuXYgaggv3fv3/vZACC03OaPdvc5Kd/+P1f/cWLF//fv39fw4AMtk5ob966bPrLY///S354//7Qh48fQxhO7d/BxgAE/1sYhE5cPna+89Se/wz+TiEMKIBH0dPJ3eNAxtTOD/r56f95pYxzOo9tVK/av9aQIbSxQl7DwuYDn6n1fwZ1i/8Chrb/NWKjXUv3rtxddmDtZIamPWuTNF3dHovYud5Q9vQ9L+fmdYuBgUGh8vCGkJK9q1IYnv7/z5o1b9J0PgYuZQYgUDYw03Li4AK6izOEgYHLEwBlq29H8mh4OQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/LandingPage/processflow.svg
/* harmony default export */ const processflow = ({"src":"/_next/static/media/processflow.8392b91f.svg","height":174,"width":856,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/LandingPage/processflow-bg.png
/* harmony default export */ const processflow_bg = ({"src":"/_next/static/media/processflow-bg.fb618b9a.png","height":1173,"width":1926,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFBAMAAACKv7BmAAAAMFBMVEUfbHkfbHgea3gea3cdanYaZ3QYZXIYZHIXZHIXY3EEVmUDVWUBVGQAU2MAUmMAUmKqfOaNAAAAIklEQVR42mM4c+buGYZ//3f9Z5g6TamCQVDQWIDBxcXFBQCmawoyUgIRwgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/ProcessFlow.jsx






const ProcessFlow = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "w-full process_bg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "font-bold text-[#F1F1F6] text-2xl text-center",
                children: "Our Simple Process"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: "object-cover object-center rounded m-auto",
                alt: "processflow",
                src: processflow
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " "
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "z-10 mx-auto  justify-between items-center sm:px-16  py-4 ",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "md:container md:mx-auto flex pt-24 md:flex-row flex-col items-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "  lg:w-full md:w-1/2 w-5/6 lg:flex-grow  lg:pr-24 md:pr-16 flex flex-col md:items-start   md:text-left text-center ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: "text-4xl md:mt-36  text-[#F1F1F6]",
                                    children: "Ready to start Reading! Subscribe Now"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: " text-[#408080] mt-8 font-medium",
                                    children: "Ready to start Reading! Subscribe Now"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex justify-center  pt-10",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "inline-flex text-white bg-[#7CC9B5] border-0 py-2 px-6 focus:outline-none hover:bg-[#447466] rounded-[23px] text-lg",
                                        children: "Get Started"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex justify-center mt-28"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "lg:max-w-lg lg:w-full md:w-1/2 w-5/6 md:items-center  ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: "object-cover object-center rounded",
                                alt: "processflow",
                                src: gettingstarted
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const Landing_Page_ProcessFlow = (ProcessFlow);

;// CONCATENATED MODULE: ./public/assets/LandingPage/pricing1.png
/* harmony default export */ const pricing1 = ({"src":"/_next/static/media/pricing1.138d5511.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA4ElEQVR42h2PvUpDQRCFB66dhQh5AUsLO59BsLEQ0gl21rHRN7BWEG5nKl9AfAJBwSAWCSRVIKRIEfL/c3dndndOZjPwweE7w8CQJBwYBO4UHrgy6girQ4MkaUF5YoznVUKPpyPwYgzLw+wMK1XPnCSZR2DQ+on9v1bI2dwE0Fo+01wLsKgSf5RNfJZvWFbK2Vn3lBdeVgxsvUr52MDrQwMbrz47654pqZ5Uom4dgZu7+3BZv8VSABe0Cw1HlMdLuAjA7L/dxdf3L1t+9257bND+FYOYXQ3AtXFqkDdCQrEDYdjOuZXxtpAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/LandingPage/arrow.png
/* harmony default export */ const arrow = ({"src":"/_next/static/media/arrow.45bb9c1c.png","height":104,"width":112,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA4ElEQVR42jXBzSuDAQDH8Z+Sg/9AuRAH9x3kIFkSByHtSBxpbScWDkI7aVdKiZLLOOygSIlSK0rWDthxbbX3Ws/enufZs++2wz4fZQqlPnUAC5Zlh41K9QkIAP3qAfzR7x+8p2es759wfR+hbBivwICAsfhfwtHQDJpctjXrcaRB8+IuDHAkwHPzEEHjc0339i4bh0G0uuXM7+yRKxRfBLie3z+QJlquTZ+z5D9Ao27TFwxRb5jn6qpUa5ehq1s0vYamVlj0Boj9/qeAYfVYtn38FYsn36Kf+XQm+wiMSFIbbKaEuXzrYooAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/Pricing.jsx






function Pricing() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: " w-full h-screen mt-20 md:h-full md:mb-96 pricing_bg ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: "  absolute w-16 right-0 mt-20 transform -scale-x-100",
                src: Leaf1,
                alt: ""
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "max-w-md mx-auto  pt-10  text-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-4xl font-extrabold mb-6 lg:text-4xl text-[#015464]",
                        children: "Choose Your Plan"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-sm text-[#015464] font-medium",
                        children: "We can optimize your site so you’ll get more and more traffic leads and sales in no time."
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " mx-auto flex  sm:px-16",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "  md-px-24 relative  container  mx-auto ",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid grid-cols-1   md:grid-cols-1  lg:grid-cols-3  ",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-80 h-96 lg:w-72 lg:h-72  lg:pt-14  m-auto mt-10  max-w-sm -top-10",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: pricing1,
                                        alt: "",
                                        className: " rounded-t-2xl shadow-2xl lg:w-full 2xl:w-72 2xl:h-80 object-cover bg-white"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "bg-white shadow-2xl rounded-b-3xl pb-6 justify-center",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "w-5/6 m-auto",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    className: "text-center text-[#015464] text-2xl font-bold pt-6",
                                                    children: "SILVER PLAN"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "lg:hidden text-center text-gray-500 pt-5 text-sm",
                                                    children: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quod deserunt quia doloremque saepe consequuntur veritatis repellat earum assumenda, nihil aspernatur, "
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                    className: "text-center pt-2 text-5xl text-[#015464] font-bold",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "text-2xl mt-2 ",
                                                            children: "₹"
                                                        }),
                                                        " 50"
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-center text-gray-500 pt-1 text-sm",
                                                    children: "PER MONTH"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "lg:text-sm  text-lg font-bold relative -bottom-14  lg:hidden  left-1/2 transform -translate-x-1/2    text-white rounded-xl",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: arrow,
                                                        alt: ""
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " w-80 h-96 lg:w-72 lg:h-72 mt-96  mx-auto lg:mt-16 max-w-sm",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: pricing1,
                                        alt: "",
                                        className: " rounded-t-2xl shadow-2xl lg:w-full 2xl:w-80 2xl:h-80 object-cover bg-white"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "bg-white shadow-2xl rounded-b-3xl  justify-center",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "w-5/6 m-auto",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    className: "text-center text-[#015464] text-2xl font-bold pt-6",
                                                    children: "PLATINUM PLAN"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-center text-gray-500 pt-5 text-sm",
                                                    children: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quod deserunt quia doloremque saepe consequuntur veritatis repellat earum assumenda, nihil aspernatur, "
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                    className: "text-center pt-5 text-5xl text-[#015464] font-bold",
                                                    children: [
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "text-2xl mt-2 ",
                                                            children: "₹"
                                                        }),
                                                        " 100"
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-center text-gray-500 pt-1 text-sm",
                                                    children: "PER MONTH"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "lg:text-sm  text-lg font-bold relative -bottom-10 left-1/2 transform -translate-x-1/2  px-4  text-white rounded-xl",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: arrow,
                                                        alt: ""
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-80 h-96 lg:w-72 lg:h-72 mt-96 lg:py-14  m-auto lg:mt-16 max-w-sm",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: pricing1,
                                        alt: "",
                                        className: " rounded-t-2xl shadow-2xl lg:w-full 2xl:w-72 2xl:h-80 object-cover bg-white"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "bg-white shadow-2xl rounded-b-3xl pb-6 justify-center",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "w-5/6 m-auto",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    className: "text-center text-[#015464] text-2xl font-bold pt-6",
                                                    children: "GOLD PLAN"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "lg:hidden text-center text-gray-500 pt-5 text-sm",
                                                    children: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quod deserunt quia doloremque saepe consequuntur veritatis repellat earum assumenda, nihil aspernatur, "
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                    className: "text-center pt-5 text-5xl text-[#015464] font-bold",
                                                    children: [
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "text-2xl mt-2 ",
                                                            children: "₹"
                                                        }),
                                                        " 300"
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-center text-gray-500 pt-1 text-sm",
                                                    children: "PER MONTH"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "lg:text-sm  text-lg font-bold relative -bottom-14  lg:hidden  left-1/2 transform -translate-x-1/2    text-white rounded-xl",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: arrow,
                                                        alt: ""
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/Flipbook.jsx

const Flipbook_proxy = (0,module_proxy.createProxy)(String.raw`C:\Project\e-nool-frontend\app\Pages\Userside\Landing Page\Flipbook.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Flipbook_esModule, $$typeof: Flipbook_$$typeof } = Flipbook_proxy;
const Flipbook_default_ = Flipbook_proxy.default;


/* harmony default export */ const Flipbook = ((/* unused pure expression or super */ null && (Flipbook_default_)));
;// CONCATENATED MODULE: ./public/assets/LandingPage/Trending curve.png
/* harmony default export */ const Trending_curve = ({"src":"/_next/static/media/Trending curve.55448e49.png","height":500,"width":1920,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAQ0lEQVR4nB2KwQ2AMBDDHApPxDiMwjBMwWxsAg9EpeZ66iNSLFt/9RnBbsctsUk6gDV3JX963hrNJgNSUibRxodlLnSrtRhXrmWs/wAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./public/assets/LandingPage/brand-1.png
/* harmony default export */ const brand_1 = ({"src":"/_next/static/media/brand-1.9bf7e49b.png","height":136,"width":215,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAQAAADSmGXeAAAANklEQVR42l3BMQqAIAAAwDMLJFobGoKWXMUP+gaf7CreAcFkA6dLBH7Fp+my6iVKDrdHkOxWA2CaAl6zSz3WAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/LandingPage/brand-2.png
/* harmony default export */ const brand_2 = ({"src":"/_next/static/media/brand-2.2211b08a.png","height":120,"width":190,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAQAAADSmGXeAAAAPUlEQVR42jXKsQ2AIAAAsIo4GC9wcHKRzSuMv/AkL/EBCYGxSWHB4xWYjLLi1BVwqT6scxx+yT6E6JZs0ACwWAPbzb19dAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/FeaturedPublishers.jsx






function FeaturedPublishers_FeaturedPublishers() {
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: " mt-10 ",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-full md-px-24 relative  container  py-24 mx-auto px-6",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-wrap w-full mb-10 lg:flex-row flex-col",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "lg:w-1/2 w-full mb-6 lg:mb-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: "text-3xl font-bold title-font pb-4 text-[#015464] lg:w-[60%]",
                                    children: "Featured Publishers"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "h-1 w-48 bg-[#0FBF61] opacity-20 rounded"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "lg:w-1/2 w-full mb-6 lg:mb-0 lg:flex md:justify-end items-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "text-white bg-[#015464] border-0 py-2 px-6 focus:outline-none w-28 h-10 rounded-[21px] text-sm",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: "items-center",
                                    children: "View all"
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid grid-cols-2   md:grid-cols-3 lg:grid-cols-6 gap-4 lg:gap-3 ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "p-4 flex flex-col items-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " rounded w-auto object-cover object-center mb-6",
                                src: brand_1,
                                alt: "content"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "p-4 flex flex-col items-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " rounded w-auto object-cover object-center mb-6",
                                src: brand_2,
                                alt: "content"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "p-4 flex flex-col items-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " rounded w-auto object-cover object-center mb-6",
                                src: brand_1,
                                alt: "content"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "p-4 flex flex-col items-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " rounded w-auto object-cover object-center mb-6",
                                src: brand_2,
                                alt: "content"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "p-4 flex flex-col items-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " rounded w-auto object-cover object-center mb-6",
                                src: brand_1,
                                alt: "content"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "p-4 flex flex-col items-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: " rounded w-auto object-cover object-center mb-6",
                                src: brand_2,
                                alt: "content"
                            })
                        })
                    ]
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./public/assets/LandingPage/featured-author.png
/* harmony default export */ const featured_author = ({"src":"/_next/static/media/featured-author.1a83dfae.png","height":99,"width":99,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AbG7uo6zr65xp6ikABUXHQDg5ucAAPHwAGyBggAjMTKPAa63tf+5qqYA697W/z0tIwHk6/EAmKm7/zpcXwE8S00AAaq2t//938//IQr6AQcHBADe3eYA3eHhAM39F/8kRUsBAaa1t/8SAPQAPyIMANLNygD45+oA5+zuAM8MKgAIJy4AAaWzs////fsAUywNAN+tsQDO4OQA4Pz8APQwTQAIERQAAaexsP/o7/L/NRgDAS0L8wCztL0A2vMIAAg2R//3/P4BAaSrqf/39/cA6O7x/1AoCgHn3NwAscDS/wUtPAENFBUAAamooo7X1tdxsL/GAOft9AAfCP0Ays7QAAAAAABGVVmPEWx+vnaXhS4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/FeaturedAuthors.jsx




function FeaturedAuthors_FeaturedAuthors() {
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: " mt-10 text-gray-600",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-full md-px-24 relative  container  py-24 mx-auto px-6 ",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-wrap w-full mb-10 lg:flex-row flex-col",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "lg:w-1/2 w-full mb-6 lg:mb-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: "text-3xl font-bold title-font pb-4 text-[#015464] lg:w-[60%]",
                                    children: "Featured Authors"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "h-1 w-48 bg-[#0FBF61] opacity-20 rounded"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "lg:w-1/2 w-full mb-6 lg:mb-0 lg:flex md:justify-end items-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "text-white bg-[#015464] border-0 py-2 px-6 focus:outline-none w-28 h-10 rounded-[21px] text-sm",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: "items-center",
                                    children: "View all"
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid grid-cols-2   md:grid-cols-3 lg:grid-cols-6 gap-4 lg:gap-3 ",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "p-4 flex flex-col items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded w-auto object-cover object-center mb-6",
                                    src: featured_author,
                                    alt: "content"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-bold text-[#015464]",
                                    children: "Arthur Gonzalez"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "p-4 flex flex-col items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    className: "rounded-xl w-auto object-cover object-center mb-6",
                                    src: "https://i.pravatar.cc/99",
                                    alt: "content"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-bold text-[#015464]",
                                    children: "Arthur Gonzalez"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "p-4 flex flex-col items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-xl w-auto object-cover object-center mb-6",
                                    src: featured_author,
                                    alt: "content"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-bold text-[#015464]",
                                    children: "Arthur Gonzalez"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "p-4 flex flex-col items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    className: "rounded-xl w-auto object-cover object-center mb-6",
                                    src: "https://i.pravatar.cc/99",
                                    alt: "content"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-bold text-[#015464]",
                                    children: "Arthur Gonzalez"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "p-4 flex flex-col items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-xl w-auto object-cover object-center mb-6",
                                    src: featured_author,
                                    alt: "content"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-bold text-[#015464]",
                                    children: "Arthur Gonzalez"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "p-4 flex flex-col items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    className: "rounded-xl w-auto object-cover object-center mb-6",
                                    src: "https://i.pravatar.cc/99",
                                    alt: "content"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-bold text-[#015464]",
                                    children: "Arthur Gonzalez"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./app/components/Login/page.jsx
var page = __webpack_require__(4663);
;// CONCATENATED MODULE: ./public/assets/LandingPage/getting-started.png
/* harmony default export */ const getting_started = ({"src":"/_next/static/media/getting-started.e3960a6c.png","height":390,"width":650,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAApElEQVR42mOo7lnXXtq8tKO2Y3VXRPGcSTktm2QZGBgUgZiJAQTevP3xf/exU/9nrtnw/8WLD/+fPPphtX1a15XQsNhOsILvP/7/f/z84//Lt5//f/fpz/8vN64s/Hvv5v+TKxbPASu4+/Cbx63bn0KePv2RcOnhx9/HLz68v3vx4v97Zk0oYkACsxj4xK7HFpR/88ss/8+gH/Cfwcz5oWdkvBQAK+BXiYt8AJQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/LandingPage/getting-started1.png
/* harmony default export */ const getting_started1 = ({"src":"/_next/static/media/getting-started1.e9754c80.png","height":222,"width":384,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAn0lEQVR42mMAgaaIVhYQ3eKmmdzpHngBxP7//z/ThWnTWRlK+64xfprLwAwUYlwwaWvGrL7u/wzmdvMY0MHm3lO1K2ff+L95347fGflN/7f3L1z2Y8tGb6DMMs7LbVNjLk1o/v/yYOX/61sm/F+w9NL/g6uP/n+zbs0thomTZkw53T+5rzE69XJ1hsfd5vKiB3MXn328fcnRS6+XL00BALnmTmCO/lhqAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/LandingPage/gettingstarted-bg.png
/* harmony default export */ const gettingstarted_bg = ({"src":"/_next/static/media/gettingstarted-bg.a5b290e6.png","height":519,"width":1992,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAQElEQVR4nGPULqlbxsTELPbn758/jIyMDJwcHAxAiuHrtx8sLIyMLxmtGzo//vr7l48BCkCKQODf//8MHCwsHwGUShL/VfhZ4AAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/GetStarted.jsx






const GetStarted = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "w-full relative",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute z-0 h-full w-full",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    className: "h-full w-full object-cover object-center",
                    src: gettingstarted_bg,
                    alt: ""
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "z-10 relative mx-auto justify-between items-center sm:px-16 py-4",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "md:container md:mx-auto flex pt-24 md:flex-row flex-col items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "lg:max-w-lg lg:w-full md:w-1/2 w-5/6 md:items-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: "object-cover object-center rounded",
                                alt: "hero",
                                src: getting_started
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "relative lg:w-full md:w-1/2 w-5/6 lg:flex-grow lg:pl-24 md:pl-16 flex flex-col md:items-start md:text-left mt-7 text-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: "text-4xl font-bold md:mt-36 text-white",
                                    children: "Become an Enool Publisher Partner"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-white mt-8 font-medium",
                                    children: "Start selling beautiful, accessible eBooks on ENOOL"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex justify-center pt-10",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "inline-flex text-white bg-[#7CC9B5] border-0 py-2 px-6 focus:outline-none hover:bg-[#447466] rounded-[23px] text-lg",
                                        children: "Get Started"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex justify-center mt-28"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "sm:invisible lg:visible lg:block absolute bottom-0 right-0 object-cover object-center rounded",
                                    alt: "hero",
                                    src: getting_started1
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const Landing_Page_GetStarted = (GetStarted);

// EXTERNAL MODULE: ./app/components/Signup1/page.jsx
var Signup1_page = __webpack_require__(4386);
// EXTERNAL MODULE: ./app/components/OtpPage/page.jsx
var OtpPage_page = __webpack_require__(3631);
;// CONCATENATED MODULE: ./public/assets/LandingPage/TrendingReads1.png
/* harmony default export */ const LandingPage_TrendingReads1 = ({"src":"/_next/static/media/TrendingReads1.4eb9fa83.png","height":325,"width":219,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAYAAAAx8TU7AAAApUlEQVR42gWASQsBUQCAvzeeeJqQLCMODoSDcnLg7CD+s6NycVHKOFizZB37YJ5Es1F9qGReKYmerfcixukmS9GfIq5Y3BDFVJDQ6RwyVvMj8mKjBz3KCZfVVngC0BUrSd08M3Zcuju+stNqI/SHXCYK7x+zvo0sWBGseIDBcEOtmuYwDWKE9ZPl8YPfyjLZuZgvxzDs0fZ5f3iYPq2d65frK3D/A31JRVVfb/alAAAAAElFTkSuQmCC","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/eye.png
/* harmony default export */ const icons_eye = ({"src":"/_next/static/media/eye.8e1cf272.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAiUlEQVR42h2MoQ7CMBiE/wyB4BWYIYEEwRMRHEgc8GwYzJaxYLCoViwD0bGK9hcrTXq0u0vu8pmP9IRi3vNPnn4kldsrG7b2phYRn1N+tXjEtmApZvTbSlSuCEWonIQ70HAUuPsSZVyB4UJqaUOD2te+gUW3SeadCQyGgd4nzIi6VX/qz981kc7+NxNTSfzkxDQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/heart.png
/* harmony default export */ const icons_heart = ({"src":"/_next/static/media/heart.a243bf33.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA30lEQVR42j2OvdLBQBSGd3zNV7gFGoVC4YbM6JQ6lMS/xkhsskmI8TMksli/jcJ96NwDjcmM42QHO/PMnnPeOe95CfU3f+TzujM3hsS//U/TuYgjZxzcqS8eWF+QhBRtcfjXXH5VdAvKmgHlvgGKboLq8pslDlFib0+ZhuUA8uyMpq+OM3k17dGzbg7B2h5zhK33+bYzAYWaAdvsIQTdgtZwDGy9K5Hewk/ibahQJoWqYQfhmT7O1IWfljkwQ5ZyAaFtjQ0Ag4Lm8ZwUVW8VCf/efJlE+wJSRNeUXPRWkTcUtYcL8MFpggAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/more-options-dotted.png
/* harmony default export */ const more_options_dotted = ({"src":"/_next/static/media/more-options-dotted.14481e7f.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA0UlEQVR42mM4+v0VMwMUHP32Sg7Il4fx4XK7X92TB3J2H/328jMQfwEq3L/nzX1lsOTpvx85zv7/fPPEr7f/T/39AMYgNlDswYmfb3kZjv14Hdu0dM7/LQ+v/px5YNu/2Yd2/Nv04MrPlmVz/x//9TYdpCCvacns/1seXfs98+C2/7MP7/i/+cGV381ATcd/vqlgOP7jtcaZ/5/+Q634DcInfr/9DxIDatZnAIFDn58lAB35Hxkf+vw8HSx57OdrJqgXNYASZUBcDmTrQOTeMAEAkjWsaybrdaoAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./app/components/Cards/Cards.jsx







const Cards_Cards = ()=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: "grid grid-cols-2   md:grid-cols-3 lg:grid-cols-6 gap-4 lg:gap-3",
        children: [
            /*#__PURE__*/ _jsxs("div", {
                children: [
                    /*#__PURE__*/ _jsx(Image, {
                        className: " rounded w-56 object-cover object-center mb-4",
                        src: TrendingReads1,
                        alt: "content"
                    }),
                    /*#__PURE__*/ _jsx("h2", {
                        className: "text-[16px] text-[#1A6270] font-bold   mb-2",
                        children: "King of Battle and Blood"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-wrap mb-2",
                        children: [
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-gray-300 dark:text-gray-500",
                                "aria-hidden": "true",
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("p", {
                                className: "tracking-widest text-[#280c0c] text-xs  ",
                                children: "(27)"
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        className: "text-[12px] tracking-widest text-[#1A6270] text-xs  mb-2  ",
                        children: "by Scarlett St.Clair"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-wrap space-x-4 pt-2 mb-1",
                        children: [
                            /*#__PURE__*/ _jsx(Image, {
                                src: eye,
                                className: "w-8",
                                alt: ""
                            }),
                            /*#__PURE__*/ _jsx(Image, {
                                src: heart,
                                className: "w-8",
                                alt: ""
                            }),
                            /*#__PURE__*/ _jsx(Image, {
                                src: moreOption,
                                className: "w-8",
                                alt: ""
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("div", {
                children: [
                    /*#__PURE__*/ _jsx(Image, {
                        className: " rounded w-56 object-cover object-center mb-4",
                        src: TrendingReads1,
                        alt: "content"
                    }),
                    /*#__PURE__*/ _jsx("h2", {
                        className: "text-[16px] text-[#1A6270] font-bold   mb-2",
                        children: "King of Battle and Blood"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-wrap mb-2",
                        children: [
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-gray-300 dark:text-gray-500",
                                "aria-hidden": "true",
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("p", {
                                className: "tracking-widest text-[#280c0c] text-xs  ",
                                children: "(27)"
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        className: "text-[12px] tracking-widest text-[#1A6270] text-xs  mb-2  ",
                        children: "by Scarlett St.Clair"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-wrap space-x-4 pt-2 mb-1",
                        children: [
                            /*#__PURE__*/ _jsx(Image, {
                                src: eye,
                                className: "w-8",
                                alt: ""
                            }),
                            /*#__PURE__*/ _jsx(Image, {
                                src: heart,
                                className: "w-8",
                                alt: ""
                            }),
                            /*#__PURE__*/ _jsx(Image, {
                                src: moreOption,
                                className: "w-8",
                                alt: ""
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("div", {
                children: [
                    /*#__PURE__*/ _jsx(Image, {
                        className: " rounded w-56 object-cover object-center mb-4",
                        src: TrendingReads1,
                        alt: "content"
                    }),
                    /*#__PURE__*/ _jsx("h2", {
                        className: "text-[16px] text-[#1A6270] font-bold   mb-2",
                        children: "King of Battle and Blood"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-wrap mb-2",
                        children: [
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-gray-300 dark:text-gray-500",
                                "aria-hidden": "true",
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("p", {
                                className: "tracking-widest text-[#280c0c] text-xs  ",
                                children: "(27)"
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        className: "text-[12px] tracking-widest text-[#1A6270] text-xs  mb-2  ",
                        children: "by Scarlett St.Clair"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-wrap space-x-4 pt-2 mb-1",
                        children: [
                            /*#__PURE__*/ _jsx(Image, {
                                src: eye,
                                className: "w-8",
                                alt: ""
                            }),
                            /*#__PURE__*/ _jsx(Image, {
                                src: heart,
                                className: "w-8",
                                alt: ""
                            }),
                            /*#__PURE__*/ _jsx(Image, {
                                src: moreOption,
                                className: "w-8",
                                alt: ""
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("div", {
                children: [
                    /*#__PURE__*/ _jsx(Image, {
                        className: " rounded w-56 object-cover object-center mb-4",
                        src: TrendingReads1,
                        alt: "content"
                    }),
                    /*#__PURE__*/ _jsx("h2", {
                        className: "text-[16px] text-[#1A6270] font-bold   mb-2",
                        children: "King of Battle and Blood"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-wrap mb-2",
                        children: [
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-gray-300 dark:text-gray-500",
                                "aria-hidden": "true",
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("p", {
                                className: "tracking-widest text-[#280c0c] text-xs  ",
                                children: "(27)"
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        className: "text-[12px] tracking-widest text-[#1A6270] text-xs  mb-2  ",
                        children: "by Scarlett St.Clair"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-wrap space-x-4 pt-2 mb-1",
                        children: [
                            /*#__PURE__*/ _jsx(Image, {
                                src: eye,
                                className: "w-8",
                                alt: ""
                            }),
                            /*#__PURE__*/ _jsx(Image, {
                                src: heart,
                                className: "w-8",
                                alt: ""
                            }),
                            /*#__PURE__*/ _jsx(Image, {
                                src: moreOption,
                                className: "w-8",
                                alt: ""
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("div", {
                children: [
                    /*#__PURE__*/ _jsx(Image, {
                        className: " rounded w-56 object-cover object-center mb-4",
                        src: TrendingReads1,
                        alt: "content"
                    }),
                    /*#__PURE__*/ _jsx("h2", {
                        className: "text-[16px] text-[#1A6270] font-bold   mb-2",
                        children: "King of Battle and Blood"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-wrap mb-2",
                        children: [
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-gray-300 dark:text-gray-500",
                                "aria-hidden": "true",
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("p", {
                                className: "tracking-widest text-[#280c0c] text-xs  ",
                                children: "(27)"
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        className: "text-[12px] tracking-widest text-[#1A6270] text-xs  mb-2  ",
                        children: "by Scarlett St.Clair"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-wrap space-x-4 pt-2 mb-1",
                        children: [
                            /*#__PURE__*/ _jsx(Image, {
                                src: eye,
                                className: "w-8",
                                alt: ""
                            }),
                            /*#__PURE__*/ _jsx(Image, {
                                src: heart,
                                className: "w-8",
                                alt: ""
                            }),
                            /*#__PURE__*/ _jsx(Image, {
                                src: moreOption,
                                className: "w-8",
                                alt: ""
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("div", {
                children: [
                    /*#__PURE__*/ _jsx(Image, {
                        className: " rounded w-56 object-cover object-center mb-4",
                        src: TrendingReads1,
                        alt: "content"
                    }),
                    /*#__PURE__*/ _jsx("h2", {
                        className: "text-[16px] text-[#1A6270] font-bold   mb-2",
                        children: "King of Battle and Blood"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-wrap mb-2",
                        children: [
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-gray-300 dark:text-gray-500",
                                "aria-hidden": "true",
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("p", {
                                className: "tracking-widest text-[#280c0c] text-xs  ",
                                children: "(27)"
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        className: "text-[12px] tracking-widest text-[#1A6270] text-xs  mb-2  ",
                        children: "by Scarlett St.Clair"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-wrap space-x-4 pt-2 mb-1",
                        children: [
                            /*#__PURE__*/ _jsx(Image, {
                                src: eye,
                                className: "w-8",
                                alt: ""
                            }),
                            /*#__PURE__*/ _jsx(Image, {
                                src: heart,
                                className: "w-8",
                                alt: ""
                            }),
                            /*#__PURE__*/ _jsx(Image, {
                                src: moreOption,
                                className: "w-8",
                                alt: ""
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("div", {
                children: [
                    /*#__PURE__*/ _jsx(Image, {
                        className: " rounded w-56 object-cover object-center mb-4",
                        src: TrendingReads1,
                        alt: "content"
                    }),
                    /*#__PURE__*/ _jsx("h2", {
                        className: "text-[16px] text-[#1A6270] font-bold   mb-2",
                        children: "King of Battle and Blood"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-wrap mb-2",
                        children: [
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-yellow-300",
                                "aria-hidden": "true",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("svg", {
                                className: "w-4 h-4 text-gray-300 dark:text-gray-500",
                                "aria-hidden": "true",
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "currentColor",
                                viewBox: "0 0 22 20",
                                children: /*#__PURE__*/ _jsx("path", {
                                    d: "M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
                                })
                            }),
                            /*#__PURE__*/ _jsx("p", {
                                className: "tracking-widest text-[#280c0c] text-xs  ",
                                children: "(27)"
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        className: "text-[12px] tracking-widest text-[#1A6270] text-xs  mb-2  ",
                        children: "by Scarlett St.Clair"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex flex-wrap space-x-4 pt-2 mb-1",
                        children: [
                            /*#__PURE__*/ _jsx(Image, {
                                src: eye,
                                className: "w-8",
                                alt: ""
                            }),
                            /*#__PURE__*/ _jsx(Image, {
                                src: heart,
                                className: "w-8",
                                alt: ""
                            }),
                            /*#__PURE__*/ _jsx(Image, {
                                src: moreOption,
                                className: "w-8",
                                alt: ""
                            })
                        ]
                    })
                ]
            })
        ]
    });
} // import React from 'react'
 // import Image from 'next/image';
 // import TrendingReads1 from 'public/assets/LandingPage/TrendingReads1.png';
 // import eye from 'public/icons/eye.png';
 // import heart from 'public/icons/heart.png';
 // import moreOption from 'public/icons/more-options-dotted.png';
 // const Cards = ({ bookImg, title, rating, author }) => {
 //     return (
 //         <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
 //             <div>
 //                 <Image className=" rounded w-56 object-cover object-center mb-4" src={bookImg} alt="bookCategories" />
 //                 <h2 className="text-[16px] text-[#1A6270] font-bold   mb-2">{title}</h2>
 //                 <div className="flex flex-wrap mb-2">
 //                     {Array.from({ length: rating }, (_, index) => (
 //                         <svg key={index} className="w-4 h-4 text-yellow-300" aria-hidden="true" fill="currentColor" viewBox="0 0 22 20">
 //                             <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
 //                         </svg>
 //                     ))}
 //                     <p className="tracking-widest text-[#280c0c] text-xs ">({rating})</p>
 //                 </div>
 //                 <p className="text-[12px] tracking-widest text-[#1A6270] text-xs  mb-2  ">{`by ${author}`}</p>
 //                 <div className="flex flex-wrap space-x-4 pt-2 mb-1">
 //                     <Image src={eye} className="w-8" alt="" />
 //                     <Image src={heart} className="w-8" alt="" />
 //                     <Image src={moreOption} className="w-8" alt="" />
 //                 </div>
 //             </div>
 //         </div>
 //     )
 // }
 // export default Cards
;

;// CONCATENATED MODULE: ./app/components/CategoriesButton/CategoriesButton.jsx

const CategoriesButton_proxy = (0,module_proxy.createProxy)(String.raw`C:\Project\e-nool-frontend\app\components\CategoriesButton\CategoriesButton.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: CategoriesButton_esModule, $$typeof: CategoriesButton_$$typeof } = CategoriesButton_proxy;
const CategoriesButton_default_ = CategoriesButton_proxy.default;


/* harmony default export */ const CategoriesButton_CategoriesButton = ((/* unused pure expression or super */ null && (CategoriesButton_default_)));
;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/BookCategories.jsx


// import { useState, useEffect } from 'react';
// import TrendingCurve from 'public/assets/LandingPage/Trending curve.png';





function BookCategories() {
    const dropdown = "/icons/dropdown.svg";
    const gridEnabled = "/icons/grid-enabled.svg";
    const listdisabled = "/icons/list-disabled.svg";
    const bookData = {
        imageSrc: TrendingReads1,
        title: "King of Battle and Blood",
        rating: 4,
        author: "Scarlett St.Clair"
    };
    return /*#__PURE__*/ _jsxs("section", {
        className: " w-full",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: " mx-auto flex justify-between items-center sm:px-16 px-6 py-4",
                children: /*#__PURE__*/ _jsxs("div", {
                    className: "  md-px-24 relative  container pt-24 mx-auto",
                    children: [
                        /*#__PURE__*/ _jsx("div", {
                            className: "flex flex-wrap w-full ",
                            children: /*#__PURE__*/ _jsx("div", {
                                className: "lg:w-1/2 w-full mb-6 lg:mb-2",
                                children: /*#__PURE__*/ _jsx("h1", {
                                    className: "text-3xl  font-bold title-font pb-4 text-[#015464]",
                                    children: "Antiques and Collectables"
                                })
                            })
                        }),
                        /*#__PURE__*/ _jsxs("div", {
                            className: "lg:flex justify-between mb-10",
                            children: [
                                /*#__PURE__*/ _jsx(CategoriesButton, {}),
                                /*#__PURE__*/ _jsxs("div", {
                                    className: "sm:flex pt-10 sm:space-x-3",
                                    children: [
                                        /*#__PURE__*/ _jsxs("button", {
                                            type: "button",
                                            className: "flex items-center justify-between w-80 sm:w-52 px-4 py-2 bg-[#EEF2F6] text-white rounded-xl hover:bg-[#EEF2F6]/90 focus:outline-none space-x-2 flex-row mb-2",
                                            children: [
                                                /*#__PURE__*/ _jsx("span", {
                                                    className: "pl-5 text-[#015464] text-sm ",
                                                    children: "Show: All"
                                                }),
                                                /*#__PURE__*/ _jsx("img", {
                                                    src: dropdown,
                                                    alt: "Dropdown",
                                                    className: "w-3 h-3"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ _jsxs("button", {
                                            type: "button",
                                            className: "flex items-center justify-between w-80 sm:w-52 px-4 py-2 bg-[#EEF2F6] text-white rounded-xl hover:bg-[#EEF2F6]/90 focus:outline-none space-x-2 flex-row mb-2",
                                            children: [
                                                /*#__PURE__*/ _jsx("span", {
                                                    className: "pl-5 text-[#015464] text-sm",
                                                    children: "Short By: Publisher"
                                                }),
                                                /*#__PURE__*/ _jsx("img", {
                                                    src: dropdown,
                                                    alt: "Dropdown",
                                                    className: "w-3 h-3"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ _jsx("button", {
                                            children: /*#__PURE__*/ _jsx("img", {
                                                src: gridEnabled,
                                                alt: "gridEnabled",
                                                className: "px-2 w-10"
                                            })
                                        }),
                                        /*#__PURE__*/ _jsx("button", {
                                            children: /*#__PURE__*/ _jsx("img", {
                                                src: listdisabled,
                                                alt: "listdisabled",
                                                className: "px-2 w-9 items-center"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsx("div", {
                            className: "h-[2px] w-full bg-[#0FBF61] opacity-20 rounded mb-5"
                        }),
                        /*#__PURE__*/ _jsx(Cards, {})
                    ]
                })
            }),
            /*#__PURE__*/ _jsx(FeaturedAuthors, {}),
            /*#__PURE__*/ _jsx(FeaturedPublishers, {})
        ]
    });
}

;// CONCATENATED MODULE: ./app/Pages/Userside/Landing Page/Page.jsx

















function Page_page() {
    return(// <About />
    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "hero_bg hero_bg_1 ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Hero, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(TrendingReads, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Landing_Page_ProcessFlow, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(BrowseCategories, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(FeaturedAuthors_FeaturedAuthors, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Testimonials, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(FeaturedPublishers_FeaturedPublishers, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Landing_Page_GetStarted, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Landing_Page_About, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Pricing, {})
        ]
    }));
}

;// CONCATENATED MODULE: ./app/page.js


function Home() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Page_page, {})
    });
}


/***/ }),

/***/ 1066:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Leaf1.0c89d817.png","height":348,"width":93,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAAICAYAAADTLS5CAAAAT0lEQVR4nGN0aC7g+xZl+p3R8vh0KwZmJm5Gi3NztBj//nNntDg/R5zh3/9wRouzs6UZ/jPYghhyQIYUo+WpmUL/mRilGS1frmf48/AlHwC1wBsCvAxfDgAAAABJRU5ErkJggg==","blurWidth":2,"blurHeight":8});

/***/ }),

/***/ 3742:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Leaf2.7cd3c653.png","height":321,"width":164,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAfElEQVR42mNIOzBRzmdnCwcDEITu7mBkSN4/IS92b09Z8O52AQYQiNrbbZi4r29G5J4uPQYYSNjXZ5eyf6IfAwiUHJnFmnFgskzqgYnWmQcn2zLE7O1hSdrfXwI0UKjs6Gw2BhBIOzDJCSjIywADhYdnyBQdninCwMDAAAD7WCsf8H+m5wAAAABJRU5ErkJggg==","blurWidth":4,"blurHeight":8});

/***/ }),

/***/ 7834:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Trending curve.55448e49.png","height":500,"width":1920,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAQ0lEQVR4nB2KwQ2AMBDDHApPxDiMwjBMwWxsAg9EpeZ66iNSLFt/9RnBbsctsUk6gDV3JX963hrNJgNSUibRxodlLnSrtRhXrmWs/wAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 4546:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/TrendingReads1.4eb9fa83.png","height":325,"width":219,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAYAAAAx8TU7AAAApUlEQVR42gWASQsBUQCAvzeeeJqQLCMODoSDcnLg7CD+s6NycVHKOFizZB37YJ5Es1F9qGReKYmerfcixukmS9GfIq5Y3BDFVJDQ6RwyVvMj8mKjBz3KCZfVVngC0BUrSd08M3Zcuju+stNqI/SHXCYK7x+zvo0sWBGseIDBcEOtmuYwDWKE9ZPl8YPfyjLZuZgvxzDs0fZ5f3iYPq2d65frK3D/A31JRVVfb/alAAAAAElFTkSuQmCC","blurWidth":5,"blurHeight":8});

/***/ }),

/***/ 4079:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/about object.8f71b8f0.png","height":604,"width":505,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAMAAAAC2hU0AAAAUVBMVEUl6r8g6MIo38Em374n3r8n3r4m3r8m3r4n3b8n3b4m3b4o278AAAAn3r8n3r4m3r8m3r4n3b8n3b4m3b4n3r8n3r4m3r8m3r4n3b8n3b4m3b9/obNWAAAAG3RSTlMAAAAAAAAAAAAAAAAAAQEBAQEBAQICAgICAgJi4TjxAAAAPElEQVR42gVAARZAIAz9WC2jDGuT+x+0h3xZ88wQVQ5h5OZUO6M/y1E0YImSyItQrHupKN923mQg8zHin1fhAubBzyqMAAAAAElFTkSuQmCC","blurWidth":7,"blurHeight":8});

/***/ }),

/***/ 6465:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/about1.a8d01b83.png","height":591,"width":583,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA2klEQVR42mN4fecxKwMUTM8pLwFSUD4UvD5zNQVM1wn67esofPLg/r25bx7faQQKyRbWx4oz3Fq6ku3/v/9sb1utDOt6O9/cvf/k//2HL/6f3rz24ZTO8tkMUMCxo6XE6cK1u9cfPfvw//6Td78+La/9/2laRjcDCBzee8Ds4tye7y9efPj/9NWXny9fvP/x6OyZ/9tWbZjBAALzFq+RretYdO3i9Xtfjp659P/9x9//d5648mJqTVMoAxQwN/Su9jh04kLc9GUrJr7/8DPl6ZM3fv///xdgIAQAtkt3zfx7c+EAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/about2.1a47e32a.png","height":132,"width":173,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAjklEQVR42mN4e+3uwjcXby1+e/O+87vbD8UZgODd3UeMDDDw9tYD4zcXbv5/dezSf6DCUAYgeH36KjMDMgDqjni570z+bYYGdgZ08ObybSYGIHi6Yi/Hq5NX2BiA4MWOE5JAjDDl/cOnTC/2nmF/vv24KFBCCoh1X2w/zsiADTzfcYIVqEAYiMWe7zghAAAI3krn4BvhyAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 7202:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/arrow.45bb9c1c.png","height":104,"width":112,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA4ElEQVR42jXBzSuDAQDH8Z+Sg/9AuRAH9x3kIFkSByHtSBxpbScWDkI7aVdKiZLLOOygSIlSK0rWDthxbbX3Ws/enufZs++2wz4fZQqlPnUAC5Zlh41K9QkIAP3qAfzR7x+8p2es759wfR+hbBivwICAsfhfwtHQDJpctjXrcaRB8+IuDHAkwHPzEEHjc0339i4bh0G0uuXM7+yRKxRfBLie3z+QJlquTZ+z5D9Ao27TFwxRb5jn6qpUa5ehq1s0vYamVlj0Boj9/qeAYfVYtn38FYsn36Kf+XQm+wiMSFIbbKaEuXzrYooAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 8763:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/brand-1.9bf7e49b.png","height":136,"width":215,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAQAAADSmGXeAAAANklEQVR42l3BMQqAIAAAwDMLJFobGoKWXMUP+gaf7CreAcFkA6dLBH7Fp+my6iVKDrdHkOxWA2CaAl6zSz3WAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 5029:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/brand-2.2211b08a.png","height":120,"width":190,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAQAAADSmGXeAAAAPUlEQVR42jXKsQ2AIAAAsIo4GC9wcHKRzSuMv/AkL/EBCYGxSWHB4xWYjLLi1BVwqT6scxx+yT6E6JZs0ACwWAPbzb19dAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 8590:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/featured-author.1a83dfae.png","height":99,"width":99,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AbG7uo6zr65xp6ikABUXHQDg5ucAAPHwAGyBggAjMTKPAa63tf+5qqYA697W/z0tIwHk6/EAmKm7/zpcXwE8S00AAaq2t//938//IQr6AQcHBADe3eYA3eHhAM39F/8kRUsBAaa1t/8SAPQAPyIMANLNygD45+oA5+zuAM8MKgAIJy4AAaWzs////fsAUywNAN+tsQDO4OQA4Pz8APQwTQAIERQAAaexsP/o7/L/NRgDAS0L8wCztL0A2vMIAAg2R//3/P4BAaSrqf/39/cA6O7x/1AoCgHn3NwAscDS/wUtPAENFBUAAamooo7X1tdxsL/GAOft9AAfCP0Ays7QAAAAAABGVVmPEWx+vnaXhS4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 2730:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/getting-started.e3960a6c.png","height":390,"width":650,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAApElEQVR42mOo7lnXXtq8tKO2Y3VXRPGcSTktm2QZGBgUgZiJAQTevP3xf/exU/9nrtnw/8WLD/+fPPphtX1a15XQsNhOsILvP/7/f/z84//Lt5//f/fpz/8vN64s/Hvv5v+TKxbPASu4+/Cbx63bn0KePv2RcOnhx9/HLz68v3vx4v97Zk0oYkACsxj4xK7HFpR/88ss/8+gH/Cfwcz5oWdkvBQAK+BXiYt8AJQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 2473:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/getting-started1.e9754c80.png","height":222,"width":384,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAn0lEQVR42mMAgaaIVhYQ3eKmmdzpHngBxP7//z/ThWnTWRlK+64xfprLwAwUYlwwaWvGrL7u/wzmdvMY0MHm3lO1K2ff+L95347fGflN/7f3L1z2Y8tGb6DMMs7LbVNjLk1o/v/yYOX/61sm/F+w9NL/g6uP/n+zbs0thomTZkw53T+5rzE69XJ1hsfd5vKiB3MXn328fcnRS6+XL00BALnmTmCO/lhqAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 3814:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/gettingstarted-bg.a5b290e6.png","height":519,"width":1992,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAQElEQVR4nGPULqlbxsTELPbn758/jIyMDJwcHAxAiuHrtx8sLIyMLxmtGzo//vr7l48BCkCKQODf//8MHCwsHwGUShL/VfhZ4AAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 5972:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/gettingstarted.815a3250.png","height":622,"width":654,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/UlEQVR42mP49u3bnx8/fmxkAAKDSx9YGYDg29cvuh8/fvz/5cuXYgaggv3fv3/vZACC03OaPdvc5Kd/+P1f/cWLF//fv39fw4AMtk5ob966bPrLY///S354//7Qh48fQxhO7d/BxgAE/1sYhE5cPna+89Se/wz+TiEMKIBH0dPJ3eNAxtTOD/r56f95pYxzOo9tVK/av9aQIbSxQl7DwuYDn6n1fwZ1i/8Chrb/NWKjXUv3rtxddmDtZIamPWuTNF3dHovYud5Q9vQ9L+fmdYuBgUGh8vCGkJK9q1IYnv7/z5o1b9J0PgYuZQYgUDYw03Li4AK6izOEgYHLEwBlq29H8mh4OQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 7295:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/pricing1.138d5511.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA4ElEQVR42h2PvUpDQRCFB66dhQh5AUsLO59BsLEQ0gl21rHRN7BWEG5nKl9AfAJBwSAWCSRVIKRIEfL/c3dndndOZjPwweE7w8CQJBwYBO4UHrgy6girQ4MkaUF5YoznVUKPpyPwYgzLw+wMK1XPnCSZR2DQ+on9v1bI2dwE0Fo+01wLsKgSf5RNfJZvWFbK2Vn3lBdeVgxsvUr52MDrQwMbrz47654pqZ5Uom4dgZu7+3BZv8VSABe0Cw1HlMdLuAjA7L/dxdf3L1t+9257bND+FYOYXQ3AtXFqkDdCQrEDYdjOuZXxtpAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 6963:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/processflow-bg.fb618b9a.png","height":1173,"width":1926,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFBAMAAACKv7BmAAAAMFBMVEUfbHkfbHgea3gea3cdanYaZ3QYZXIYZHIXZHIXY3EEVmUDVWUBVGQAU2MAUmMAUmKqfOaNAAAAIklEQVR42mM4c+buGYZ//3f9Z5g6TamCQVDQWIDBxcXFBQCmawoyUgIRwgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 362:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/processflow.8392b91f.svg","height":174,"width":856,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 7541:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/eye.8e1cf272.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAiUlEQVR42h2MoQ7CMBiE/wyB4BWYIYEEwRMRHEgc8GwYzJaxYLCoViwD0bGK9hcrTXq0u0vu8pmP9IRi3vNPnn4kldsrG7b2phYRn1N+tXjEtmApZvTbSlSuCEWonIQ70HAUuPsSZVyB4UJqaUOD2te+gUW3SeadCQyGgd4nzIi6VX/qz981kc7+NxNTSfzkxDQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 8197:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/heart.a243bf33.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA30lEQVR42j2OvdLBQBSGd3zNV7gFGoVC4YbM6JQ6lMS/xkhsskmI8TMksli/jcJ96NwDjcmM42QHO/PMnnPeOe95CfU3f+TzujM3hsS//U/TuYgjZxzcqS8eWF+QhBRtcfjXXH5VdAvKmgHlvgGKboLq8pslDlFib0+ZhuUA8uyMpq+OM3k17dGzbg7B2h5zhK33+bYzAYWaAdvsIQTdgtZwDGy9K5Hewk/ibahQJoWqYQfhmT7O1IWfljkwQ5ZyAaFtjQ0Ag4Lm8ZwUVW8VCf/efJlE+wJSRNeUXPRWkTcUtYcL8MFpggAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 3327:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/more-options-dotted.14481e7f.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA0UlEQVR42mM4+v0VMwMUHP32Sg7Il4fx4XK7X92TB3J2H/328jMQfwEq3L/nzX1lsOTpvx85zv7/fPPEr7f/T/39AMYgNlDswYmfb3kZjv14Hdu0dM7/LQ+v/px5YNu/2Yd2/Nv04MrPlmVz/x//9TYdpCCvacns/1seXfs98+C2/7MP7/i/+cGV381ATcd/vqlgOP7jtcaZ/5/+Q634DcInfr/9DxIDatZnAIFDn58lAB35Hxkf+vw8HSx57OdrJqgXNYASZUBcDmTrQOTeMAEAkjWsaybrdaoAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [152,131,320,750,210,769,638,392,51], () => (__webpack_exec__(9477)));
module.exports = __webpack_exports__;

})();